# PySNMP, version 4
majorVersionId = '4'
