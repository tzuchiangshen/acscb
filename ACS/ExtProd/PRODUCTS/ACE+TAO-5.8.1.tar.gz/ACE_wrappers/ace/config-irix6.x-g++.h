/* -*- C++ -*- */
// $Id: config-irix6.x-g++.h 87268 2009-10-29 21:06:06Z olli $

// The following configuration file is designed to work for the SGI
// Indigo2EX running Irix 6.2 platform using the GNU C++ Compiler

#ifndef ACE_CONFIG_H
#define ACE_CONFIG_H
#include /**/ "ace/pre.h"

#include "ace/config-g++-common.h"
#include "ace/config-irix6.x-common.h"

#include /**/ "ace/post.h"
#endif /* ACE_CONFIG_H */
