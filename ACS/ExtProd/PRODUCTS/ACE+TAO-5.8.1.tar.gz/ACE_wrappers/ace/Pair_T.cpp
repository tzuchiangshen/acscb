// $Id: Pair_T.cpp 80826 2008-03-04 14:51:23Z wotte $

#ifndef ACE_PAIR_T_CPP
#define ACE_PAIR_T_CPP

#include "ace/Pair_T.h"

#if !defined (ACE_LACKS_PRAGMA_ONCE)
# pragma once
#endif /* ACE_LACKS_PRAGMA_ONCE */

#if !defined (__ACE_INLINE__)
#include "ace/Pair_T.inl"
#endif /* __ACE_INLINE__ */

#endif /* ACE_PAIR_T_CPP */
