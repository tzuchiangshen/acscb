#include "ace/Functor_String.h"

#if !defined (__ACE_INLINE__)
#include "ace/Functor_String.inl"
#endif /* __ACE_INLINE__ */

ACE_RCSID(ace, Functor, "$Id: Functor_String.cpp 80826 2008-03-04 14:51:23Z wotte $")
