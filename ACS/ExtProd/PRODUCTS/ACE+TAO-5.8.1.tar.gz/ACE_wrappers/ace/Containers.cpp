// $Id: Containers.cpp 80826 2008-03-04 14:51:23Z wotte $

#include "ace/Containers.h"

ACE_RCSID (ace,
           Containers,
           "$Id: Containers.cpp 80826 2008-03-04 14:51:23Z wotte $")

#if !defined (__ACE_INLINE__)
#include "ace/Containers.inl"
#endif /* __ACE_INLINE__ */

