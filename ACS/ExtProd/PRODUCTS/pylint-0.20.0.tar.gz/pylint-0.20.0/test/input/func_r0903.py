"""test min methods"""
__revision__ = None

class Aaaa:
    """yo"""
    def __init__(self):
        pass
    def meth1(self):
        """hehehe"""
        print self
    def _dontcount(self):
        """not public"""
        print self
