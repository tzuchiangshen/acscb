"""check use of l as long int marker 
"""

__revision__ = 1l
