==============
IPython README
==============

Overview
========

Welcome to IPython. Our documentation can be found in the docs/source
subdirectory. We also have ``.html`` and ``.pdf`` versions of this
documentation available on the IPython `website <http://ipython.scipy.org>`_.

