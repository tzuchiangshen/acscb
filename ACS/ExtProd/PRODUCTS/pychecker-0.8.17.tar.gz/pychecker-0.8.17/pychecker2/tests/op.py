def f(a):
    return ++a

def g(a):
    return +a

def g(a):
    return --a

def foo():
    if 1 == None:
        print "whoa!"
    else:
        print "whew!"

    if None == 1:
        print "whoa!"
    else:
        print "whew!"

def bar():
    a = b = 0
    if 'a' <= b >= 'c':
        print ""
