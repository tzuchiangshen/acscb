
class N1:
    class N2:
        x = 1
        class N3:
            pass

        
