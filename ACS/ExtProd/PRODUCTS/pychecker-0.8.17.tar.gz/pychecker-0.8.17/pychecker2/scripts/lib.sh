#! /bin/sh
scripts/pychecker2.sh --incremental --no-importError --no-unused --no-shadowIdentifier --no-shadowImport --no-emptyExcept --no-attributeInitialized /usr/local/lib/python2.2/*.py
