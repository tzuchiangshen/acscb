'd'

class Ccc:
  'd'
  def __init__(self, c):
    pass

class Ddd:
  'd'
  def __init__(self):
    self.ccc = Ccc(1)

