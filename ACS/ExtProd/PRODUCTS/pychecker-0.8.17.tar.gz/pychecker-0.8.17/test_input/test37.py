'd'

import struct
from import37 import Test

def x():
    print struct
