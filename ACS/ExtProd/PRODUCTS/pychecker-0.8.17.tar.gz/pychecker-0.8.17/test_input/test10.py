"doc"

from xml.sax import saxutils

def afunc():
    stuff = saxutils.escape.make_parser('junk')
    return stuff

