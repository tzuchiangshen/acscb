"doesn't work in 1.5.2"

import string
import string as nn

used = ''
_unused = 0

def yyy():
    import string as jj

if nn.lower('aa') == '':
    pass
if string.lower(used) == '':
    pass

if 1 :
    _noglobal = 0

import xml.sax as sax

def zzz():
    print sax

