'd'

def x(): pass

import test46
from test46 import x
from test46 import *
