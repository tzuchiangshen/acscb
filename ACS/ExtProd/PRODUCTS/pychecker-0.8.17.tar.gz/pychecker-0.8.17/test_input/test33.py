'd'

def x():
    print j
    j = 0

def y():
    for x in []:
        print x

