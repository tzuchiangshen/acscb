'd'

def x(v):
  count = 0
  if v != 0:
    return 1
  return count

def y(v):
  x = len(v)
  if x == 0 :
    return x
  else :
    return x - 1

