'doc'

import sys

class A:
    'doc'
    z = 1
    def x(self): pass

def xxx():
    print A.x()
    print A.z
    print A.a
    print A.y()
    print sys.lkjsdflksjasdlf

