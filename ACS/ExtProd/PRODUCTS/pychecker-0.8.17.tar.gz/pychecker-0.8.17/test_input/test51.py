'd'

def x():
    n = []
    d = {}
    print n[5]
    print n[5,-3]
    print n[1,3]
    print n[1:3]
    print n[1:-3]

    print d[5]
    print d[5,-3]
    print d[1,3]
    print d[1:3]
    print d[1:-3]

    print [1, 2][1]

