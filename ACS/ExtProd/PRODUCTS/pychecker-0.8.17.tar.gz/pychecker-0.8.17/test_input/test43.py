'd'

class GameObject:
    'd'
    # def isIntersecting(self, other): pass
    pass

class SoAndSo(GameObject):
    'd'
    def isIntersecting(self, other):
        return GameObject.isIntersecting(self, other)
