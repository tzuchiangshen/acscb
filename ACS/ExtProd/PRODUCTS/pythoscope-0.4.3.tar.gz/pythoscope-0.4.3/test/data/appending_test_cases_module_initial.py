class SomeClass(object):
    def __init__(self):
        pass

    def some_method(self):
        pass
