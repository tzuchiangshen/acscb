from module import main
main()
