import unittest

class TestSomeClass(unittest.TestCase):
    def test___init__(self):
        assert True # implemented test case

    def test_some_method(self):
        assert True # implemented test case

if __name__ == '__main__':
    unittest.main()
