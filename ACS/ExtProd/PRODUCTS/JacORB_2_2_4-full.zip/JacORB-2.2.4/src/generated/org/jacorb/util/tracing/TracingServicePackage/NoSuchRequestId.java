package org.jacorb.util.tracing.TracingServicePackage;

/**
 *	Generated from IDL definition of exception "NoSuchRequestId"
 *	@author JacORB IDL compiler 
 */

public final class NoSuchRequestId
	extends org.omg.CORBA.UserException
{
	public NoSuchRequestId()
	{
		super(org.jacorb.util.tracing.TracingServicePackage.NoSuchRequestIdHelper.id());
	}

	public NoSuchRequestId(String value)
	{
		super(value);
	}
}
