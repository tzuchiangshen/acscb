/*
 * Generated file - Do not edit!
 */
package org.jacorb.notification.filter.etcl;

/**
 * MBean interface.
 */
public interface ETCLFilterMBean extends org.jacorb.notification.filter.AbstractFilterMBean {

}
