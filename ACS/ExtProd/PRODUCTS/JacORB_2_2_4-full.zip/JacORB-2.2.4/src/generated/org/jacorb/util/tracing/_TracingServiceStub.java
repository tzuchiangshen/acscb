package org.jacorb.util.tracing;


/**
 *	Generated from IDL interface "TracingService"
 *	@author JacORB IDL compiler V 2.2.3, 10-Dec-2005
 */

public class _TracingServiceStub
	extends org.omg.CORBA.portable.ObjectImpl
	implements org.jacorb.util.tracing.TracingService
{
	private String[] ids = {"IDL:org/jacorb/util/tracing/TracingService:1.0"};
	public String[] _ids()
	{
		return ids;
	}

	public final static java.lang.Class _opsClass = org.jacorb.util.tracing.TracingServiceOperations.class;
	public int get_id()
	{
		while(true)
		{
		if(! this._is_local())
		{
			org.omg.CORBA.portable.InputStream _is = null;
			try
			{
				org.omg.CORBA.portable.OutputStream _os = _request( "get_id", true);
				_is = _invoke(_os);
				int _result = _is.read_long();
				return _result;
			}
			catch( org.omg.CORBA.portable.RemarshalException _rx ){}
			catch( org.omg.CORBA.portable.ApplicationException _ax )
			{
				String _id = _ax.getId();
				throw new RuntimeException("Unexpected exception " + _id );
			}
			finally
			{
				this._releaseReply(_is);
			}
		}
		else
		{
			org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke( "get_id", _opsClass );
			if( _so == null )
				throw new org.omg.CORBA.UNKNOWN("local invocations not supported!");
			TracingServiceOperations _localServant = (TracingServiceOperations)_so.servant;
			int _result;			try
			{
			_result = _localServant.get_id();
			}
			finally
			{
				_servant_postinvoke(_so);
			}
			return _result;
		}

		}

	}

	public void logTraceAtPoint(org.jacorb.util.tracing.Request origin, java.lang.String operation, long client_time, long server_time) throws org.jacorb.util.tracing.TracingServicePackage.NoSuchRequestId
	{
		while(true)
		{
		if(! this._is_local())
		{
			org.omg.CORBA.portable.InputStream _is = null;
			try
			{
				org.omg.CORBA.portable.OutputStream _os = _request( "logTraceAtPoint", true);
				org.jacorb.util.tracing.RequestHelper.write(_os,origin);
				_os.write_string(operation);
				_os.write_longlong(client_time);
				_os.write_longlong(server_time);
				_is = _invoke(_os);
				return;
			}
			catch( org.omg.CORBA.portable.RemarshalException _rx ){}
			catch( org.omg.CORBA.portable.ApplicationException _ax )
			{
				String _id = _ax.getId();
				if( _id.equals("IDL:org/jacorb/util/tracing/TracingService/NoSuchRequestId:1.0"))
				{
					throw org.jacorb.util.tracing.TracingServicePackage.NoSuchRequestIdHelper.read(_ax.getInputStream());
				}
				else 
					throw new RuntimeException("Unexpected exception " + _id );
			}
			finally
			{
				this._releaseReply(_is);
			}
		}
		else
		{
			org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke( "logTraceAtPoint", _opsClass );
			if( _so == null )
				throw new org.omg.CORBA.UNKNOWN("local invocations not supported!");
			TracingServiceOperations _localServant = (TracingServiceOperations)_so.servant;
			try
			{
			_localServant.logTraceAtPoint(origin,operation,client_time,server_time);
			}
			finally
			{
				_servant_postinvoke(_so);
			}
			return;
		}

		}

	}

	public org.jacorb.util.tracing.TraceData getTrace(org.jacorb.util.tracing.Request source) throws org.jacorb.util.tracing.TracingServicePackage.NoSuchRequestId
	{
		while(true)
		{
		if(! this._is_local())
		{
			org.omg.CORBA.portable.InputStream _is = null;
			try
			{
				org.omg.CORBA.portable.OutputStream _os = _request( "getTrace", true);
				org.jacorb.util.tracing.RequestHelper.write(_os,source);
				_is = _invoke(_os);
				org.jacorb.util.tracing.TraceData _result = org.jacorb.util.tracing.TraceDataHelper.read(_is);
				return _result;
			}
			catch( org.omg.CORBA.portable.RemarshalException _rx ){}
			catch( org.omg.CORBA.portable.ApplicationException _ax )
			{
				String _id = _ax.getId();
				if( _id.equals("IDL:org/jacorb/util/tracing/TracingService/NoSuchRequestId:1.0"))
				{
					throw org.jacorb.util.tracing.TracingServicePackage.NoSuchRequestIdHelper.read(_ax.getInputStream());
				}
				else 
					throw new RuntimeException("Unexpected exception " + _id );
			}
			finally
			{
				this._releaseReply(_is);
			}
		}
		else
		{
			org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke( "getTrace", _opsClass );
			if( _so == null )
				throw new org.omg.CORBA.UNKNOWN("local invocations not supported!");
			TracingServiceOperations _localServant = (TracingServiceOperations)_so.servant;
			org.jacorb.util.tracing.TraceData _result;			try
			{
			_result = _localServant.getTrace(source);
			}
			finally
			{
				_servant_postinvoke(_so);
			}
			return _result;
		}

		}

	}

	public void registerSubTrace(org.jacorb.util.tracing.Request original, org.jacorb.util.tracing.Request nested) throws org.jacorb.util.tracing.TracingServicePackage.NoSuchRequestId
	{
		while(true)
		{
		if(! this._is_local())
		{
			org.omg.CORBA.portable.InputStream _is = null;
			try
			{
				org.omg.CORBA.portable.OutputStream _os = _request( "registerSubTrace", true);
				org.jacorb.util.tracing.RequestHelper.write(_os,original);
				org.jacorb.util.tracing.RequestHelper.write(_os,nested);
				_is = _invoke(_os);
				return;
			}
			catch( org.omg.CORBA.portable.RemarshalException _rx ){}
			catch( org.omg.CORBA.portable.ApplicationException _ax )
			{
				String _id = _ax.getId();
				if( _id.equals("IDL:org/jacorb/util/tracing/TracingService/NoSuchRequestId:1.0"))
				{
					throw org.jacorb.util.tracing.TracingServicePackage.NoSuchRequestIdHelper.read(_ax.getInputStream());
				}
				else 
					throw new RuntimeException("Unexpected exception " + _id );
			}
			finally
			{
				this._releaseReply(_is);
			}
		}
		else
		{
			org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke( "registerSubTrace", _opsClass );
			if( _so == null )
				throw new org.omg.CORBA.UNKNOWN("local invocations not supported!");
			TracingServiceOperations _localServant = (TracingServiceOperations)_so.servant;
			try
			{
			_localServant.registerSubTrace(original,nested);
			}
			finally
			{
				_servant_postinvoke(_so);
			}
			return;
		}

		}

	}

}
