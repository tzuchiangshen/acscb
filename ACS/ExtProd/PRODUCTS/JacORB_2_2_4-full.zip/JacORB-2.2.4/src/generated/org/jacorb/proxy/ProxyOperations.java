package org.jacorb.proxy;

/**
 *	Generated from IDL interface "Proxy"
 *	@author JacORB IDL compiler V 2.2.3, 10-Dec-2005
 */


public interface ProxyOperations
{
}
