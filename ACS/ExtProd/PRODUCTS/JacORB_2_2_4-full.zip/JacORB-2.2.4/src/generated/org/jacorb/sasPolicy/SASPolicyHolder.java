package org.jacorb.sasPolicy;

/**
 *	Generated from IDL interface "SASPolicy"
 *	@author JacORB IDL compiler V 2.2.3, 10-Dec-2005
 */

public final class SASPolicyHolder	implements org.omg.CORBA.portable.Streamable{
	 public SASPolicy value;
	public SASPolicyHolder()
	{
	}
	public SASPolicyHolder (final SASPolicy initial)
	{
		value = initial;
	}
	public org.omg.CORBA.TypeCode _type()
	{
		return SASPolicyHelper.type();
	}
	public void _read (final org.omg.CORBA.portable.InputStream in)
	{
		value = SASPolicyHelper.read (in);
	}
	public void _write (final org.omg.CORBA.portable.OutputStream _out)
	{
		SASPolicyHelper.write (_out,value);
	}
}
