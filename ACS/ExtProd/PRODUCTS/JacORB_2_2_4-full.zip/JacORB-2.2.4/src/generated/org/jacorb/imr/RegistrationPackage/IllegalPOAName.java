package org.jacorb.imr.RegistrationPackage;

/**
 *	Generated from IDL definition of exception "IllegalPOAName"
 *	@author JacORB IDL compiler 
 */

public final class IllegalPOAName
	extends org.omg.CORBA.UserException
{
	public IllegalPOAName()
	{
		super(org.jacorb.imr.RegistrationPackage.IllegalPOANameHelper.id());
	}

	public java.lang.String name;
	public IllegalPOAName(java.lang.String _reason,java.lang.String name)
	{
		super(org.jacorb.imr.RegistrationPackage.IllegalPOANameHelper.id()+ " " + _reason);
		this.name = name;
	}
	public IllegalPOAName(java.lang.String name)
	{
		super(org.jacorb.imr.RegistrationPackage.IllegalPOANameHelper.id());
		this.name = name;
	}
}
