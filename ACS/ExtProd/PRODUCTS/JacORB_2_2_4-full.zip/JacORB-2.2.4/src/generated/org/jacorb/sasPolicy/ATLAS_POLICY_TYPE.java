package org.jacorb.sasPolicy;
/**
 * Automatically generated from IDL const definition 
 * @author JacORB IDL compiler 
 */

public interface ATLAS_POLICY_TYPE
{
	int value = 103;
}
