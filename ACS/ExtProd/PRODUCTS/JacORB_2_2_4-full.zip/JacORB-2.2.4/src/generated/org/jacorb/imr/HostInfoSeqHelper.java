package org.jacorb.imr;

/**
 *	Generated from IDL definition of alias "HostInfoSeq"
 *	@author JacORB IDL compiler 
 */

public final class HostInfoSeqHelper
{
	private static org.omg.CORBA.TypeCode _type = null;

	public static void insert (org.omg.CORBA.Any any, org.jacorb.imr.HostInfo[] s)
	{
		any.type (type ());
		write (any.create_output_stream (), s);
	}

	public static org.jacorb.imr.HostInfo[] extract (final org.omg.CORBA.Any any)
	{
		return read (any.create_input_stream ());
	}

	public static org.omg.CORBA.TypeCode type ()
	{
		if (_type == null)
		{
			_type = org.omg.CORBA.ORB.init().create_alias_tc(org.jacorb.imr.HostInfoSeqHelper.id(), "HostInfoSeq",org.omg.CORBA.ORB.init().create_sequence_tc(0, org.jacorb.imr.HostInfoHelper.type()));
		}
		return _type;
	}

	public static String id()
	{
		return "IDL:org/jacorb/imr/HostInfoSeq:1.0";
	}
	public static org.jacorb.imr.HostInfo[] read (final org.omg.CORBA.portable.InputStream _in)
	{
		org.jacorb.imr.HostInfo[] _result;
		int _l_result128 = _in.read_long();
		_result = new org.jacorb.imr.HostInfo[_l_result128];
		for (int i=0;i<_result.length;i++)
		{
			_result[i]=org.jacorb.imr.HostInfoHelper.read(_in);
		}

		return _result;
	}

	public static void write (final org.omg.CORBA.portable.OutputStream _out, org.jacorb.imr.HostInfo[] _s)
	{
		
		_out.write_long(_s.length);
		for (int i=0; i<_s.length;i++)
		{
			org.jacorb.imr.HostInfoHelper.write(_out,_s[i]);
		}

	}
}
