package org.jacorb.util.tracing;

/**
 *	Generated from IDL definition of struct "TraceData"
 *	@author JacORB IDL compiler 
 */

public final class TraceData
	implements org.omg.CORBA.portable.IDLEntity
{
	public TraceData(){}
	public org.jacorb.util.tracing.TraceData[] subtrace;
	public int tracer_id;
	public java.lang.String operation = "";
	public long client_time;
	public long trace_system_time;
	public TraceData(org.jacorb.util.tracing.TraceData[] subtrace, int tracer_id, java.lang.String operation, long client_time, long trace_system_time)
	{
		this.subtrace = subtrace;
		this.tracer_id = tracer_id;
		this.operation = operation;
		this.client_time = client_time;
		this.trace_system_time = trace_system_time;
	}
}
