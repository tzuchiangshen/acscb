package org.jacorb.imr;

/**
 *	Generated from IDL interface "ServerStartupDaemon"
 *	@author JacORB IDL compiler V 2.2.3, 10-Dec-2005
 */


public interface ServerStartupDaemonOperations
{
	/* constants */
	/* operations  */
	int get_system_load();
	void start_server(java.lang.String command) throws org.jacorb.imr.ServerStartupFailed;
}
