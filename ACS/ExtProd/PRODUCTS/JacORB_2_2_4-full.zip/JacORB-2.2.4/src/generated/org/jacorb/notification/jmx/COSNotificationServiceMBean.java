/*
 * Generated file - Do not edit!
 */
package org.jacorb.notification.jmx;

/**
 * MBean interface.
 */
public interface COSNotificationServiceMBean {

  java.lang.String createChannel() ;

  java.lang.String getIOR() ;

  java.lang.String getCorbaloc() ;

  java.lang.String getIORFile() ;

  void setIORFile(java.lang.String filename) throws java.io.IOException;

  java.lang.String getCOSNamingEntry() ;

  void setCOSNamingEntry(java.lang.String registerName) ;

}
