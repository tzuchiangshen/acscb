package org.jacorb.imr;

/**
 *	Generated from IDL definition of exception "ServerStartupFailed"
 *	@author JacORB IDL compiler 
 */

public final class ServerStartupFailed
	extends org.omg.CORBA.UserException
{
	public ServerStartupFailed()
	{
		super(org.jacorb.imr.ServerStartupFailedHelper.id());
	}

	public java.lang.String reason = "";
	public ServerStartupFailed(java.lang.String _reason,java.lang.String reason)
	{
		super(org.jacorb.imr.ServerStartupFailedHelper.id()+ " " + _reason);
		this.reason = reason;
	}
	public ServerStartupFailed(java.lang.String reason)
	{
		super(org.jacorb.imr.ServerStartupFailedHelper.id());
		this.reason = reason;
	}
}
