package org.jacorb.ssl;
/**
 * Automatically generated from IDL const definition 
 * @author JacORB IDL compiler 
 */

public interface SSL_POLICY_TYPE
{
	int value = 101;
}
