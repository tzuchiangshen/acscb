package org.jacorb.events;

/**
 *	Generated from IDL interface "JacORBEventChannel"
 *	@author JacORB IDL compiler V 2.2.3, 10-Dec-2005
 */


public interface JacORBEventChannelOperations
	extends org.omg.CosEventChannelAdmin.EventChannelOperations , org.omg.CosEventChannelAdmin.ConsumerAdminOperations , org.omg.CosEventChannelAdmin.SupplierAdminOperations
{
}
