package org.jacorb.proxy;

import org.omg.PortableServer.POA;

/**
 *	Generated from IDL interface "Proxy"
 *	@author JacORB IDL compiler V 2.2.3, 10-Dec-2005
 */

public class ProxyPOATie
	extends ProxyPOA
{
	private ProxyOperations _delegate;

	private POA _poa;
	public ProxyPOATie(ProxyOperations delegate)
	{
		_delegate = delegate;
	}
	public ProxyPOATie(ProxyOperations delegate, POA poa)
	{
		_delegate = delegate;
		_poa = poa;
	}
	public org.jacorb.proxy.Proxy _this()
	{
		return org.jacorb.proxy.ProxyHelper.narrow(_this_object());
	}
	public org.jacorb.proxy.Proxy _this(org.omg.CORBA.ORB orb)
	{
		return org.jacorb.proxy.ProxyHelper.narrow(_this_object(orb));
	}
	public ProxyOperations _delegate()
	{
		return _delegate;
	}
	public void _delegate(ProxyOperations delegate)
	{
		_delegate = delegate;
	}
	public POA _default_POA()
	{
		if (_poa != null)
		{
			return _poa;
		}
		else
		{
			return super._default_POA();
		}
	}
}
