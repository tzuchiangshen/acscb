package org.jacorb.imr;

/**
 *	Generated from IDL interface "Admin"
 *	@author JacORB IDL compiler V 2.2.3, 10-Dec-2005
 */

public interface Admin
	extends AdminOperations, org.omg.CORBA.Object, org.omg.CORBA.portable.IDLEntity
{
}
