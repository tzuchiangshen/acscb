package org.jacorb.imr.AdminPackage;

/**
 *	Generated from IDL definition of exception "FileOpFailed"
 *	@author JacORB IDL compiler 
 */

public final class FileOpFailed
	extends org.omg.CORBA.UserException
{
	public FileOpFailed()
	{
		super(org.jacorb.imr.AdminPackage.FileOpFailedHelper.id());
	}

	public FileOpFailed(String value)
	{
		super(value);
	}
}
