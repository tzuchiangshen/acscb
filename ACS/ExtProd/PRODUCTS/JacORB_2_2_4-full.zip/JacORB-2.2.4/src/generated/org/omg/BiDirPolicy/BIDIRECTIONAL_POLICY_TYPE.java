package org.omg.BiDirPolicy;
/**
 * Automatically generated from IDL const definition 
 * @author JacORB IDL compiler 
 */

public interface BIDIRECTIONAL_POLICY_TYPE
{
	int value = 37;
}
