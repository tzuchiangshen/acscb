package org.jacorb.imr.AdminPackage;

/**
 *	Generated from IDL definition of exception "DuplicateServerName"
 *	@author JacORB IDL compiler 
 */

public final class DuplicateServerName
	extends org.omg.CORBA.UserException
{
	public DuplicateServerName()
	{
		super(org.jacorb.imr.AdminPackage.DuplicateServerNameHelper.id());
	}

	public java.lang.String name;
	public DuplicateServerName(java.lang.String _reason,java.lang.String name)
	{
		super(org.jacorb.imr.AdminPackage.DuplicateServerNameHelper.id()+ " " + _reason);
		this.name = name;
	}
	public DuplicateServerName(java.lang.String name)
	{
		super(org.jacorb.imr.AdminPackage.DuplicateServerNameHelper.id());
		this.name = name;
	}
}
