/*
 * Generated file - Do not edit!
 */
package org.jacorb.notification.jmx.jboss;

/**
 * MBean interface.
 */
public interface JBossCOSNotificationServiceMBean extends org.jboss.system.ServiceMBean {

  java.lang.String getName() ;

  int getState() ;

  java.lang.String getStateString() ;

  void create() throws java.lang.Exception;

  void start() throws java.lang.Exception;

  void stop() ;

  void destroy() ;

  java.lang.String createChannel() ;

  java.lang.String getCOSNamingEntry() ;

  void setCOSNamingEntry(java.lang.String cosNamingEntry) ;

  java.lang.String getCorbaloc() ;

  java.lang.String getIOR() ;

  java.lang.String getIORFile() ;

  void setIORFile(java.lang.String filename) throws java.io.IOException;

  void setAdditionalArguments(java.lang.String additionalArguments) ;

  java.lang.String getAdditionalArguments() ;

}
