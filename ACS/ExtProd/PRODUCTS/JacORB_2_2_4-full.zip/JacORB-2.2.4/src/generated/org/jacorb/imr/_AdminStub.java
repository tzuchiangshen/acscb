package org.jacorb.imr;


/**
 *	Generated from IDL interface "Admin"
 *	@author JacORB IDL compiler V 2.2.3, 10-Dec-2005
 */

public class _AdminStub
	extends org.omg.CORBA.portable.ObjectImpl
	implements org.jacorb.imr.Admin
{
	private String[] ids = {"IDL:org/jacorb/imr/Admin:1.0"};
	public String[] _ids()
	{
		return ids;
	}

	public final static java.lang.Class _opsClass = org.jacorb.imr.AdminOperations.class;
	public void release_server(java.lang.String name) throws org.jacorb.imr.UnknownServerName
	{
		while(true)
		{
		if(! this._is_local())
		{
			org.omg.CORBA.portable.InputStream _is = null;
			try
			{
				org.omg.CORBA.portable.OutputStream _os = _request( "release_server", true);
				_os.write_string(name);
				_is = _invoke(_os);
				return;
			}
			catch( org.omg.CORBA.portable.RemarshalException _rx ){}
			catch( org.omg.CORBA.portable.ApplicationException _ax )
			{
				String _id = _ax.getId();
				if( _id.equals("IDL:org/jacorb/imr/UnknownServerName:1.0"))
				{
					throw org.jacorb.imr.UnknownServerNameHelper.read(_ax.getInputStream());
				}
				else 
					throw new RuntimeException("Unexpected exception " + _id );
			}
			finally
			{
				this._releaseReply(_is);
			}
		}
		else
		{
			org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke( "release_server", _opsClass );
			if( _so == null )
				throw new org.omg.CORBA.UNKNOWN("local invocations not supported!");
			AdminOperations _localServant = (AdminOperations)_so.servant;
			try
			{
			_localServant.release_server(name);
			}
			finally
			{
				_servant_postinvoke(_so);
			}
			return;
		}

		}

	}

	public org.jacorb.imr.HostInfo[] list_hosts()
	{
		while(true)
		{
		if(! this._is_local())
		{
			org.omg.CORBA.portable.InputStream _is = null;
			try
			{
				org.omg.CORBA.portable.OutputStream _os = _request( "list_hosts", true);
				_is = _invoke(_os);
				org.jacorb.imr.HostInfo[] _result = org.jacorb.imr.HostInfoSeqHelper.read(_is);
				return _result;
			}
			catch( org.omg.CORBA.portable.RemarshalException _rx ){}
			catch( org.omg.CORBA.portable.ApplicationException _ax )
			{
				String _id = _ax.getId();
				throw new RuntimeException("Unexpected exception " + _id );
			}
			finally
			{
				this._releaseReply(_is);
			}
		}
		else
		{
			org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke( "list_hosts", _opsClass );
			if( _so == null )
				throw new org.omg.CORBA.UNKNOWN("local invocations not supported!");
			AdminOperations _localServant = (AdminOperations)_so.servant;
			org.jacorb.imr.HostInfo[] _result;			try
			{
			_result = _localServant.list_hosts();
			}
			finally
			{
				_servant_postinvoke(_so);
			}
			return _result;
		}

		}

	}

	public void unregister_host(java.lang.String name) throws org.jacorb.imr.AdminPackage.UnknownHostName
	{
		while(true)
		{
		if(! this._is_local())
		{
			org.omg.CORBA.portable.InputStream _is = null;
			try
			{
				org.omg.CORBA.portable.OutputStream _os = _request( "unregister_host", true);
				_os.write_string(name);
				_is = _invoke(_os);
				return;
			}
			catch( org.omg.CORBA.portable.RemarshalException _rx ){}
			catch( org.omg.CORBA.portable.ApplicationException _ax )
			{
				String _id = _ax.getId();
				if( _id.equals("IDL:org/jacorb/imr/Admin/UnknownHostName:1.0"))
				{
					throw org.jacorb.imr.AdminPackage.UnknownHostNameHelper.read(_ax.getInputStream());
				}
				else 
					throw new RuntimeException("Unexpected exception " + _id );
			}
			finally
			{
				this._releaseReply(_is);
			}
		}
		else
		{
			org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke( "unregister_host", _opsClass );
			if( _so == null )
				throw new org.omg.CORBA.UNKNOWN("local invocations not supported!");
			AdminOperations _localServant = (AdminOperations)_so.servant;
			try
			{
			_localServant.unregister_host(name);
			}
			finally
			{
				_servant_postinvoke(_so);
			}
			return;
		}

		}

	}

	public void start_server(java.lang.String name) throws org.jacorb.imr.ServerStartupFailed,org.jacorb.imr.UnknownServerName
	{
		while(true)
		{
		if(! this._is_local())
		{
			org.omg.CORBA.portable.InputStream _is = null;
			try
			{
				org.omg.CORBA.portable.OutputStream _os = _request( "start_server", true);
				_os.write_string(name);
				_is = _invoke(_os);
				return;
			}
			catch( org.omg.CORBA.portable.RemarshalException _rx ){}
			catch( org.omg.CORBA.portable.ApplicationException _ax )
			{
				String _id = _ax.getId();
				if( _id.equals("IDL:org/jacorb/imr/ServerStartupFailed:1.0"))
				{
					throw org.jacorb.imr.ServerStartupFailedHelper.read(_ax.getInputStream());
				}
				else if( _id.equals("IDL:org/jacorb/imr/UnknownServerName:1.0"))
				{
					throw org.jacorb.imr.UnknownServerNameHelper.read(_ax.getInputStream());
				}
				else 
					throw new RuntimeException("Unexpected exception " + _id );
			}
			finally
			{
				this._releaseReply(_is);
			}
		}
		else
		{
			org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke( "start_server", _opsClass );
			if( _so == null )
				throw new org.omg.CORBA.UNKNOWN("local invocations not supported!");
			AdminOperations _localServant = (AdminOperations)_so.servant;
			try
			{
			_localServant.start_server(name);
			}
			finally
			{
				_servant_postinvoke(_so);
			}
			return;
		}

		}

	}

	public org.jacorb.imr.ServerInfo[] list_servers()
	{
		while(true)
		{
		if(! this._is_local())
		{
			org.omg.CORBA.portable.InputStream _is = null;
			try
			{
				org.omg.CORBA.portable.OutputStream _os = _request( "list_servers", true);
				_is = _invoke(_os);
				org.jacorb.imr.ServerInfo[] _result = org.jacorb.imr.ServerInfoSeqHelper.read(_is);
				return _result;
			}
			catch( org.omg.CORBA.portable.RemarshalException _rx ){}
			catch( org.omg.CORBA.portable.ApplicationException _ax )
			{
				String _id = _ax.getId();
				throw new RuntimeException("Unexpected exception " + _id );
			}
			finally
			{
				this._releaseReply(_is);
			}
		}
		else
		{
			org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke( "list_servers", _opsClass );
			if( _so == null )
				throw new org.omg.CORBA.UNKNOWN("local invocations not supported!");
			AdminOperations _localServant = (AdminOperations)_so.servant;
			org.jacorb.imr.ServerInfo[] _result;			try
			{
			_result = _localServant.list_servers();
			}
			finally
			{
				_servant_postinvoke(_so);
			}
			return _result;
		}

		}

	}

	public void shutdown(boolean _wait)
	{
		while(true)
		{
		if(! this._is_local())
		{
			org.omg.CORBA.portable.InputStream _is = null;
			try
			{
				org.omg.CORBA.portable.OutputStream _os = _request( "shutdown", true);
				_os.write_boolean(_wait);
				_is = _invoke(_os);
				return;
			}
			catch( org.omg.CORBA.portable.RemarshalException _rx ){}
			catch( org.omg.CORBA.portable.ApplicationException _ax )
			{
				String _id = _ax.getId();
				throw new RuntimeException("Unexpected exception " + _id );
			}
			finally
			{
				this._releaseReply(_is);
			}
		}
		else
		{
			org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke( "shutdown", _opsClass );
			if( _so == null )
				throw new org.omg.CORBA.UNKNOWN("local invocations not supported!");
			AdminOperations _localServant = (AdminOperations)_so.servant;
			try
			{
			_localServant.shutdown(_wait);
			}
			finally
			{
				_servant_postinvoke(_so);
			}
			return;
		}

		}

	}

	public void save_server_table() throws org.jacorb.imr.AdminPackage.FileOpFailed
	{
		while(true)
		{
		if(! this._is_local())
		{
			org.omg.CORBA.portable.InputStream _is = null;
			try
			{
				org.omg.CORBA.portable.OutputStream _os = _request( "save_server_table", true);
				_is = _invoke(_os);
				return;
			}
			catch( org.omg.CORBA.portable.RemarshalException _rx ){}
			catch( org.omg.CORBA.portable.ApplicationException _ax )
			{
				String _id = _ax.getId();
				if( _id.equals("IDL:org/jacorb/imr/Admin/FileOpFailed:1.0"))
				{
					throw org.jacorb.imr.AdminPackage.FileOpFailedHelper.read(_ax.getInputStream());
				}
				else 
					throw new RuntimeException("Unexpected exception " + _id );
			}
			finally
			{
				this._releaseReply(_is);
			}
		}
		else
		{
			org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke( "save_server_table", _opsClass );
			if( _so == null )
				throw new org.omg.CORBA.UNKNOWN("local invocations not supported!");
			AdminOperations _localServant = (AdminOperations)_so.servant;
			try
			{
			_localServant.save_server_table();
			}
			finally
			{
				_servant_postinvoke(_so);
			}
			return;
		}

		}

	}

	public void hold_server(java.lang.String name) throws org.jacorb.imr.UnknownServerName
	{
		while(true)
		{
		if(! this._is_local())
		{
			org.omg.CORBA.portable.InputStream _is = null;
			try
			{
				org.omg.CORBA.portable.OutputStream _os = _request( "hold_server", true);
				_os.write_string(name);
				_is = _invoke(_os);
				return;
			}
			catch( org.omg.CORBA.portable.RemarshalException _rx ){}
			catch( org.omg.CORBA.portable.ApplicationException _ax )
			{
				String _id = _ax.getId();
				if( _id.equals("IDL:org/jacorb/imr/UnknownServerName:1.0"))
				{
					throw org.jacorb.imr.UnknownServerNameHelper.read(_ax.getInputStream());
				}
				else 
					throw new RuntimeException("Unexpected exception " + _id );
			}
			finally
			{
				this._releaseReply(_is);
			}
		}
		else
		{
			org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke( "hold_server", _opsClass );
			if( _so == null )
				throw new org.omg.CORBA.UNKNOWN("local invocations not supported!");
			AdminOperations _localServant = (AdminOperations)_so.servant;
			try
			{
			_localServant.hold_server(name);
			}
			finally
			{
				_servant_postinvoke(_so);
			}
			return;
		}

		}

	}

	public org.jacorb.imr.ServerInfo get_server_info(java.lang.String name) throws org.jacorb.imr.UnknownServerName
	{
		while(true)
		{
		if(! this._is_local())
		{
			org.omg.CORBA.portable.InputStream _is = null;
			try
			{
				org.omg.CORBA.portable.OutputStream _os = _request( "get_server_info", true);
				_os.write_string(name);
				_is = _invoke(_os);
				org.jacorb.imr.ServerInfo _result = org.jacorb.imr.ServerInfoHelper.read(_is);
				return _result;
			}
			catch( org.omg.CORBA.portable.RemarshalException _rx ){}
			catch( org.omg.CORBA.portable.ApplicationException _ax )
			{
				String _id = _ax.getId();
				if( _id.equals("IDL:org/jacorb/imr/UnknownServerName:1.0"))
				{
					throw org.jacorb.imr.UnknownServerNameHelper.read(_ax.getInputStream());
				}
				else 
					throw new RuntimeException("Unexpected exception " + _id );
			}
			finally
			{
				this._releaseReply(_is);
			}
		}
		else
		{
			org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke( "get_server_info", _opsClass );
			if( _so == null )
				throw new org.omg.CORBA.UNKNOWN("local invocations not supported!");
			AdminOperations _localServant = (AdminOperations)_so.servant;
			org.jacorb.imr.ServerInfo _result;			try
			{
			_result = _localServant.get_server_info(name);
			}
			finally
			{
				_servant_postinvoke(_so);
			}
			return _result;
		}

		}

	}

	public void edit_server(java.lang.String name, java.lang.String command, java.lang.String host) throws org.jacorb.imr.UnknownServerName
	{
		while(true)
		{
		if(! this._is_local())
		{
			org.omg.CORBA.portable.InputStream _is = null;
			try
			{
				org.omg.CORBA.portable.OutputStream _os = _request( "edit_server", true);
				_os.write_string(name);
				_os.write_string(command);
				_os.write_string(host);
				_is = _invoke(_os);
				return;
			}
			catch( org.omg.CORBA.portable.RemarshalException _rx ){}
			catch( org.omg.CORBA.portable.ApplicationException _ax )
			{
				String _id = _ax.getId();
				if( _id.equals("IDL:org/jacorb/imr/UnknownServerName:1.0"))
				{
					throw org.jacorb.imr.UnknownServerNameHelper.read(_ax.getInputStream());
				}
				else 
					throw new RuntimeException("Unexpected exception " + _id );
			}
			finally
			{
				this._releaseReply(_is);
			}
		}
		else
		{
			org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke( "edit_server", _opsClass );
			if( _so == null )
				throw new org.omg.CORBA.UNKNOWN("local invocations not supported!");
			AdminOperations _localServant = (AdminOperations)_so.servant;
			try
			{
			_localServant.edit_server(name,command,host);
			}
			finally
			{
				_servant_postinvoke(_so);
			}
			return;
		}

		}

	}

	public void unregister_server(java.lang.String name) throws org.jacorb.imr.UnknownServerName
	{
		while(true)
		{
		if(! this._is_local())
		{
			org.omg.CORBA.portable.InputStream _is = null;
			try
			{
				org.omg.CORBA.portable.OutputStream _os = _request( "unregister_server", true);
				_os.write_string(name);
				_is = _invoke(_os);
				return;
			}
			catch( org.omg.CORBA.portable.RemarshalException _rx ){}
			catch( org.omg.CORBA.portable.ApplicationException _ax )
			{
				String _id = _ax.getId();
				if( _id.equals("IDL:org/jacorb/imr/UnknownServerName:1.0"))
				{
					throw org.jacorb.imr.UnknownServerNameHelper.read(_ax.getInputStream());
				}
				else 
					throw new RuntimeException("Unexpected exception " + _id );
			}
			finally
			{
				this._releaseReply(_is);
			}
		}
		else
		{
			org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke( "unregister_server", _opsClass );
			if( _so == null )
				throw new org.omg.CORBA.UNKNOWN("local invocations not supported!");
			AdminOperations _localServant = (AdminOperations)_so.servant;
			try
			{
			_localServant.unregister_server(name);
			}
			finally
			{
				_servant_postinvoke(_so);
			}
			return;
		}

		}

	}

	public void register_server(java.lang.String name, java.lang.String command, java.lang.String host) throws org.jacorb.imr.AdminPackage.IllegalServerName,org.jacorb.imr.AdminPackage.DuplicateServerName
	{
		while(true)
		{
		if(! this._is_local())
		{
			org.omg.CORBA.portable.InputStream _is = null;
			try
			{
				org.omg.CORBA.portable.OutputStream _os = _request( "register_server", true);
				_os.write_string(name);
				_os.write_string(command);
				_os.write_string(host);
				_is = _invoke(_os);
				return;
			}
			catch( org.omg.CORBA.portable.RemarshalException _rx ){}
			catch( org.omg.CORBA.portable.ApplicationException _ax )
			{
				String _id = _ax.getId();
				if( _id.equals("IDL:org/jacorb/imr/Admin/IllegalServerName:1.0"))
				{
					throw org.jacorb.imr.AdminPackage.IllegalServerNameHelper.read(_ax.getInputStream());
				}
				else if( _id.equals("IDL:org/jacorb/imr/Admin/DuplicateServerName:1.0"))
				{
					throw org.jacorb.imr.AdminPackage.DuplicateServerNameHelper.read(_ax.getInputStream());
				}
				else 
					throw new RuntimeException("Unexpected exception " + _id );
			}
			finally
			{
				this._releaseReply(_is);
			}
		}
		else
		{
			org.omg.CORBA.portable.ServantObject _so = _servant_preinvoke( "register_server", _opsClass );
			if( _so == null )
				throw new org.omg.CORBA.UNKNOWN("local invocations not supported!");
			AdminOperations _localServant = (AdminOperations)_so.servant;
			try
			{
			_localServant.register_server(name,command,host);
			}
			finally
			{
				_servant_postinvoke(_so);
			}
			return;
		}

		}

	}

}
