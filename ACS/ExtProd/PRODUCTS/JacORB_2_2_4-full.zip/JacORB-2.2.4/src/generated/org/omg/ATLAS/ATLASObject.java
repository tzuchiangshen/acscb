package org.omg.ATLAS;
/**
 * Automatically generated from IDL const definition 
 * @author JacORB IDL compiler 
 */

public interface ATLASObject
{
	int value = 3;
}
