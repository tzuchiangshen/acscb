package org.jacorb.sasPolicy;

/**
 *	Generated from IDL definition of struct "ATLASPolicyValues"
 *	@author JacORB IDL compiler 
 */

public final class ATLASPolicyValues
	implements org.omg.CORBA.portable.IDLEntity
{
	public ATLASPolicyValues(){}
	public java.lang.String atlasURL = "";
	public java.lang.String atlasCache = "";
	public ATLASPolicyValues(java.lang.String atlasURL, java.lang.String atlasCache)
	{
		this.atlasURL = atlasURL;
		this.atlasCache = atlasCache;
	}
}
