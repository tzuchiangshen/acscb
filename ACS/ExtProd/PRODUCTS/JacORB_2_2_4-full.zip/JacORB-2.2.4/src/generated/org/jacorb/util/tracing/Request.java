package org.jacorb.util.tracing;

/**
 *	Generated from IDL definition of struct "Request"
 *	@author JacORB IDL compiler 
 */

public final class Request
	implements org.omg.CORBA.portable.IDLEntity
{
	public Request(){}
	public int originator;
	public long rid;
	public Request(int originator, long rid)
	{
		this.originator = originator;
		this.rid = rid;
	}
}
