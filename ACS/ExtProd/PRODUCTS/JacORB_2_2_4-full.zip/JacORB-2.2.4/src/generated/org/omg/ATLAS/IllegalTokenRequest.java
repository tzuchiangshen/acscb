package org.omg.ATLAS;

/**
 *	Generated from IDL definition of exception "IllegalTokenRequest"
 *	@author JacORB IDL compiler 
 */

public final class IllegalTokenRequest
	extends org.omg.CORBA.UserException
{
	public IllegalTokenRequest()
	{
		super(org.omg.ATLAS.IllegalTokenRequestHelper.id());
	}

	public int the_errnum;
	public java.lang.String the_reason = "";
	public IllegalTokenRequest(java.lang.String _reason,int the_errnum, java.lang.String the_reason)
	{
		super(org.omg.ATLAS.IllegalTokenRequestHelper.id()+ " " + _reason);
		this.the_errnum = the_errnum;
		this.the_reason = the_reason;
	}
	public IllegalTokenRequest(int the_errnum, java.lang.String the_reason)
	{
		super(org.omg.ATLAS.IllegalTokenRequestHelper.id());
		this.the_errnum = the_errnum;
		this.the_reason = the_reason;
	}
}
