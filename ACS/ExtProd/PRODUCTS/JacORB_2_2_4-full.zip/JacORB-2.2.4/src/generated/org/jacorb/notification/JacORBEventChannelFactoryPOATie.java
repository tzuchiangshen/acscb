package org.jacorb.notification;

import org.omg.PortableServer.POA;

/**
 *	Generated from IDL interface "JacORBEventChannelFactory"
 *	@author JacORB IDL compiler V 2.2.3, 10-Dec-2005
 */

public class JacORBEventChannelFactoryPOATie
	extends JacORBEventChannelFactoryPOA
{
	private JacORBEventChannelFactoryOperations _delegate;

	private POA _poa;
	public JacORBEventChannelFactoryPOATie(JacORBEventChannelFactoryOperations delegate)
	{
		_delegate = delegate;
	}
	public JacORBEventChannelFactoryPOATie(JacORBEventChannelFactoryOperations delegate, POA poa)
	{
		_delegate = delegate;
		_poa = poa;
	}
	public org.jacorb.notification.JacORBEventChannelFactory _this()
	{
		return org.jacorb.notification.JacORBEventChannelFactoryHelper.narrow(_this_object());
	}
	public org.jacorb.notification.JacORBEventChannelFactory _this(org.omg.CORBA.ORB orb)
	{
		return org.jacorb.notification.JacORBEventChannelFactoryHelper.narrow(_this_object(orb));
	}
	public JacORBEventChannelFactoryOperations _delegate()
	{
		return _delegate;
	}
	public void _delegate(JacORBEventChannelFactoryOperations delegate)
	{
		_delegate = delegate;
	}
	public POA _default_POA()
	{
		if (_poa != null)
		{
			return _poa;
		}
		else
		{
			return super._default_POA();
		}
	}
	public org.omg.CosNotifyChannelAdmin.EventChannel create_channel(org.omg.CosNotification.Property[] initial_qos, org.omg.CosNotification.Property[] initial_admin, org.omg.CORBA.IntHolder id) throws org.omg.CosNotification.UnsupportedAdmin,org.omg.CosNotification.UnsupportedQoS
	{
		return _delegate.create_channel(initial_qos,initial_admin,id);
	}

	public org.omg.CosNotifyChannelAdmin.EventChannel get_event_channel(int id) throws org.omg.CosNotifyChannelAdmin.ChannelNotFound
	{
		return _delegate.get_event_channel(id);
	}

	public int[] get_all_channels()
	{
		return _delegate.get_all_channels();
	}

	public void destroy()
	{
_delegate.destroy();
	}

}
