/*
 * Generated file - Do not edit!
 */
package org.jacorb.notification.servant;

/**
 * MBean interface.
 */
public interface StructuredProxyPullConsumerImplMBean extends org.jacorb.notification.servant.AbstractProxyConsumerMBean {

}
