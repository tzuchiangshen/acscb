package org.jacorb.imr;

/**
 *	Generated from IDL definition of struct "POAInfo"
 *	@author JacORB IDL compiler 
 */

public final class POAInfo
	implements org.omg.CORBA.portable.IDLEntity
{
	public POAInfo(){}
	public java.lang.String name;
	public java.lang.String host;
	public int port;
	public java.lang.String server;
	public boolean active;
	public POAInfo(java.lang.String name, java.lang.String host, int port, java.lang.String server, boolean active)
	{
		this.name = name;
		this.host = host;
		this.port = port;
		this.server = server;
		this.active = active;
	}
}
