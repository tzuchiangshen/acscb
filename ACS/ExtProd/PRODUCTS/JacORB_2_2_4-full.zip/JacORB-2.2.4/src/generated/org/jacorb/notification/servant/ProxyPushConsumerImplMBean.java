/*
 * Generated file - Do not edit!
 */
package org.jacorb.notification.servant;

/**
 * MBean interface.
 */
public interface ProxyPushConsumerImplMBean extends org.jacorb.notification.servant.AbstractProxyConsumerMBean {

}
