/*
 * Generated file - Do not edit!
 */
package org.jacorb.notification.engine;

/**
 * MBean interface.
 */
public interface DefaultTaskProcessorMBean {

  int getFilterWorkerPoolSize() ;

  int getPullWorkerPoolSize() ;

}
