package org.jacorb.ssl;

/**
 *	Generated from IDL interface "SSLPolicy"
 *	@author JacORB IDL compiler V 2.2.3, 10-Dec-2005
 */

public interface SSLPolicy
	extends SSLPolicyOperations, org.omg.CORBA.LocalInterface, org.omg.CORBA.portable.IDLEntity, org.omg.CORBA.Policy
{
}
