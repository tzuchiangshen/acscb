package org.jacorb.imr;


/**
 *	Generated from IDL definition of struct "ImRInfo"
 *	@author JacORB IDL compiler 
 */

public final class ImRInfoHelper
{
	private static org.omg.CORBA.TypeCode _type = null;
	public static org.omg.CORBA.TypeCode type ()
	{
		if (_type == null)
		{
			_type = org.omg.CORBA.ORB.init().create_struct_tc(org.jacorb.imr.ImRInfoHelper.id(),"ImRInfo",new org.omg.CORBA.StructMember[]{new org.omg.CORBA.StructMember("host", org.jacorb.imr.HostNameHelper.type(), null),new org.omg.CORBA.StructMember("port", org.jacorb.imr.PortNumberHelper.type(), null)});
		}
		return _type;
	}

	public static void insert (final org.omg.CORBA.Any any, final org.jacorb.imr.ImRInfo s)
	{
		any.type(type());
		write( any.create_output_stream(),s);
	}

	public static org.jacorb.imr.ImRInfo extract (final org.omg.CORBA.Any any)
	{
		return read(any.create_input_stream());
	}

	public static String id()
	{
		return "IDL:org/jacorb/imr/ImRInfo:1.0";
	}
	public static org.jacorb.imr.ImRInfo read (final org.omg.CORBA.portable.InputStream in)
	{
		org.jacorb.imr.ImRInfo result = new org.jacorb.imr.ImRInfo();
		result.host=in.read_string();
		result.port=in.read_ulong();
		return result;
	}
	public static void write (final org.omg.CORBA.portable.OutputStream out, final org.jacorb.imr.ImRInfo s)
	{
		out.write_string(s.host);
		out.write_ulong(s.port);
	}
}
