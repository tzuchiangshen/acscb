/*
 * Generated file - Do not edit!
 */
package org.jacorb.notification.servant;

/**
 * MBean interface.
 */
public interface StructuredProxyPushSupplierImplMBean extends org.jacorb.notification.servant.AbstractProxyPushSupplierMBean {

}
