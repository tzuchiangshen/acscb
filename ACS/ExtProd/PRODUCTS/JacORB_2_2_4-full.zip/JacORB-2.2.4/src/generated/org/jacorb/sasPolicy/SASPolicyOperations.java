package org.jacorb.sasPolicy;

/**
 *	Generated from IDL interface "SASPolicy"
 *	@author JacORB IDL compiler V 2.2.3, 10-Dec-2005
 */


public interface SASPolicyOperations
	extends org.omg.CORBA.PolicyOperations
{
	/* constants */
	/* operations  */
	org.jacorb.sasPolicy.SASPolicyValues value();
}
