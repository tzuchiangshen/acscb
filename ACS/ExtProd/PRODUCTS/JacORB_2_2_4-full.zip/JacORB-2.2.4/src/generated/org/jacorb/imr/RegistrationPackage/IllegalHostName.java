package org.jacorb.imr.RegistrationPackage;

/**
 *	Generated from IDL definition of exception "IllegalHostName"
 *	@author JacORB IDL compiler 
 */

public final class IllegalHostName
	extends org.omg.CORBA.UserException
{
	public IllegalHostName()
	{
		super(org.jacorb.imr.RegistrationPackage.IllegalHostNameHelper.id());
	}

	public java.lang.String name;
	public IllegalHostName(java.lang.String _reason,java.lang.String name)
	{
		super(org.jacorb.imr.RegistrationPackage.IllegalHostNameHelper.id()+ " " + _reason);
		this.name = name;
	}
	public IllegalHostName(java.lang.String name)
	{
		super(org.jacorb.imr.RegistrationPackage.IllegalHostNameHelper.id());
		this.name = name;
	}
}
