package org.jacorb.imr.AdminPackage;

/**
 *	Generated from IDL definition of exception "UnknownHostName"
 *	@author JacORB IDL compiler 
 */

public final class UnknownHostName
	extends org.omg.CORBA.UserException
{
	public UnknownHostName()
	{
		super(org.jacorb.imr.AdminPackage.UnknownHostNameHelper.id());
	}

	public java.lang.String name;
	public UnknownHostName(java.lang.String _reason,java.lang.String name)
	{
		super(org.jacorb.imr.AdminPackage.UnknownHostNameHelper.id()+ " " + _reason);
		this.name = name;
	}
	public UnknownHostName(java.lang.String name)
	{
		super(org.jacorb.imr.AdminPackage.UnknownHostNameHelper.id());
		this.name = name;
	}
}
