package org.jacorb.sasPolicy;
/**
 * Automatically generated from IDL const definition 
 * @author JacORB IDL compiler 
 */

public interface SAS_POLICY_TYPE
{
	int value = 102;
}
