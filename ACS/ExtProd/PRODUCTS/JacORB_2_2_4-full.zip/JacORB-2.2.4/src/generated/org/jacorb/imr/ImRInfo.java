package org.jacorb.imr;

/**
 *	Generated from IDL definition of struct "ImRInfo"
 *	@author JacORB IDL compiler 
 */

public final class ImRInfo
	implements org.omg.CORBA.portable.IDLEntity
{
	public ImRInfo(){}
	public java.lang.String host;
	public int port;
	public ImRInfo(java.lang.String host, int port)
	{
		this.host = host;
		this.port = port;
	}
}
