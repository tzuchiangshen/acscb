package org.omg.BridgeTransactionMgmt;

/**
 *	Generated from IDL definition of exception "TransactionActive"
 *	@author JacORB IDL compiler 
 */

public final class TransactionActive
	extends org.omg.CORBA.UserException
{
	public TransactionActive()
	{
		super(org.omg.BridgeTransactionMgmt.TransactionActiveHelper.id());
	}

	public TransactionActive(String value)
	{
		super(value);
	}
}
