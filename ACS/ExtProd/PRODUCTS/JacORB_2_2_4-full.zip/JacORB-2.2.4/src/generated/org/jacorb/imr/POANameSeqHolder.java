package org.jacorb.imr;

/**
 *	Generated from IDL definition of alias "POANameSeq"
 *	@author JacORB IDL compiler 
 */

public final class POANameSeqHolder
	implements org.omg.CORBA.portable.Streamable
{
	public java.lang.String[] value;

	public POANameSeqHolder ()
	{
	}
	public POANameSeqHolder (final java.lang.String[] initial)
	{
		value = initial;
	}
	public org.omg.CORBA.TypeCode _type ()
	{
		return POANameSeqHelper.type ();
	}
	public void _read (final org.omg.CORBA.portable.InputStream in)
	{
		value = POANameSeqHelper.read (in);
	}
	public void _write (final org.omg.CORBA.portable.OutputStream out)
	{
		POANameSeqHelper.write (out,value);
	}
}
