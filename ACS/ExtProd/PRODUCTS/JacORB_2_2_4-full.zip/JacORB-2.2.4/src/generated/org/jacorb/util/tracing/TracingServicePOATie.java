package org.jacorb.util.tracing;

import org.omg.PortableServer.POA;

/**
 *	Generated from IDL interface "TracingService"
 *	@author JacORB IDL compiler V 2.2.3, 10-Dec-2005
 */

public class TracingServicePOATie
	extends TracingServicePOA
{
	private TracingServiceOperations _delegate;

	private POA _poa;
	public TracingServicePOATie(TracingServiceOperations delegate)
	{
		_delegate = delegate;
	}
	public TracingServicePOATie(TracingServiceOperations delegate, POA poa)
	{
		_delegate = delegate;
		_poa = poa;
	}
	public org.jacorb.util.tracing.TracingService _this()
	{
		return org.jacorb.util.tracing.TracingServiceHelper.narrow(_this_object());
	}
	public org.jacorb.util.tracing.TracingService _this(org.omg.CORBA.ORB orb)
	{
		return org.jacorb.util.tracing.TracingServiceHelper.narrow(_this_object(orb));
	}
	public TracingServiceOperations _delegate()
	{
		return _delegate;
	}
	public void _delegate(TracingServiceOperations delegate)
	{
		_delegate = delegate;
	}
	public POA _default_POA()
	{
		if (_poa != null)
		{
			return _poa;
		}
		else
		{
			return super._default_POA();
		}
	}
	public int get_id()
	{
		return _delegate.get_id();
	}

	public void logTraceAtPoint(org.jacorb.util.tracing.Request origin, java.lang.String operation, long client_time, long server_time) throws org.jacorb.util.tracing.TracingServicePackage.NoSuchRequestId
	{
_delegate.logTraceAtPoint(origin,operation,client_time,server_time);
	}

	public org.jacorb.util.tracing.TraceData getTrace(org.jacorb.util.tracing.Request source) throws org.jacorb.util.tracing.TracingServicePackage.NoSuchRequestId
	{
		return _delegate.getTrace(source);
	}

	public void registerSubTrace(org.jacorb.util.tracing.Request original, org.jacorb.util.tracing.Request nested) throws org.jacorb.util.tracing.TracingServicePackage.NoSuchRequestId
	{
_delegate.registerSubTrace(original,nested);
	}

}
