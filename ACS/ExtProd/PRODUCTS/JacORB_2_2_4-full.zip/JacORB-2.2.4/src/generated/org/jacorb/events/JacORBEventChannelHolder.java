package org.jacorb.events;

/**
 *	Generated from IDL interface "JacORBEventChannel"
 *	@author JacORB IDL compiler V 2.2.3, 10-Dec-2005
 */

public final class JacORBEventChannelHolder	implements org.omg.CORBA.portable.Streamable{
	 public JacORBEventChannel value;
	public JacORBEventChannelHolder()
	{
	}
	public JacORBEventChannelHolder (final JacORBEventChannel initial)
	{
		value = initial;
	}
	public org.omg.CORBA.TypeCode _type()
	{
		return JacORBEventChannelHelper.type();
	}
	public void _read (final org.omg.CORBA.portable.InputStream in)
	{
		value = JacORBEventChannelHelper.read (in);
	}
	public void _write (final org.omg.CORBA.portable.OutputStream _out)
	{
		JacORBEventChannelHelper.write (_out,value);
	}
}
