package org.jacorb.imr;

/**
 *	Generated from IDL definition of exception "UnknownServerName"
 *	@author JacORB IDL compiler 
 */

public final class UnknownServerName
	extends org.omg.CORBA.UserException
{
	public UnknownServerName()
	{
		super(org.jacorb.imr.UnknownServerNameHelper.id());
	}

	public java.lang.String name;
	public UnknownServerName(java.lang.String _reason,java.lang.String name)
	{
		super(org.jacorb.imr.UnknownServerNameHelper.id()+ " " + _reason);
		this.name = name;
	}
	public UnknownServerName(java.lang.String name)
	{
		super(org.jacorb.imr.UnknownServerNameHelper.id());
		this.name = name;
	}
}
