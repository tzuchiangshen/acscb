/*
 * Generated file - Do not edit!
 */
package org.jacorb.notification;

/**
 * MBean interface.
 */
public interface EventChannelImplMBean extends org.jacorb.notification.AbstractEventChannelMBean {

  java.lang.String getIOR() ;

}
