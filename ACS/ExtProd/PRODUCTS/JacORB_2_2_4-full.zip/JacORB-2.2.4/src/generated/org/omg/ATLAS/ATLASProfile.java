package org.omg.ATLAS;

/**
 *	Generated from IDL definition of struct "ATLASProfile"
 *	@author JacORB IDL compiler 
 */

public final class ATLASProfile
	implements org.omg.CORBA.portable.IDLEntity
{
	public ATLASProfile(){}
	public org.omg.ATLAS.ATLASLocator the_locator;
	public byte[] the_cache_id;
	public ATLASProfile(org.omg.ATLAS.ATLASLocator the_locator, byte[] the_cache_id)
	{
		this.the_locator = the_locator;
		this.the_cache_id = the_cache_id;
	}
}
