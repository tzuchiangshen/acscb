package org.jacorb.sasPolicy;


/**
 *	Generated from IDL interface "SASPolicy"
 *	@author JacORB IDL compiler V 2.2.3, 10-Dec-2005
 */

public final class SASPolicyHelper
{
	public static void insert (final org.omg.CORBA.Any any, final org.jacorb.sasPolicy.SASPolicy s)
	{
			any.insert_Object(s);
	}
	public static org.jacorb.sasPolicy.SASPolicy extract(final org.omg.CORBA.Any any)
	{
		return narrow(any.extract_Object()) ;
	}
	public static org.omg.CORBA.TypeCode type()
	{
		return org.omg.CORBA.ORB.init().create_interface_tc("IDL:org/jacorb/sasPolicy/SASPolicy:1.0", "SASPolicy");
	}
	public static String id()
	{
		return "IDL:org/jacorb/sasPolicy/SASPolicy:1.0";
	}
	public static SASPolicy read(final org.omg.CORBA.portable.InputStream in)
	{
		throw new org.omg.CORBA.MARSHAL();
	}
	public static void write(final org.omg.CORBA.portable.OutputStream _out, final org.jacorb.sasPolicy.SASPolicy s)
	{
		throw new org.omg.CORBA.MARSHAL();
	}
	public static org.jacorb.sasPolicy.SASPolicy narrow(final java.lang.Object obj)
	{
		if (obj instanceof org.jacorb.sasPolicy.SASPolicy)
		{
			return (org.jacorb.sasPolicy.SASPolicy)obj;
		}
		else if (obj instanceof org.omg.CORBA.Object)
		{
			return narrow((org.omg.CORBA.Object)obj);
		}
		throw new org.omg.CORBA.BAD_PARAM("Failed to narrow in helper");
	}
	public static org.jacorb.sasPolicy.SASPolicy narrow(final org.omg.CORBA.Object obj)
	{
		if (obj == null)
			return null;
		if (obj instanceof org.jacorb.sasPolicy.SASPolicy)
			return (org.jacorb.sasPolicy.SASPolicy)obj;
		else
		throw new org.omg.CORBA.BAD_PARAM("Narrow failed, not a org.jacorb.sasPolicy.SASPolicy");
	}
	public static org.jacorb.sasPolicy.SASPolicy unchecked_narrow(final org.omg.CORBA.Object obj)
	{
		if (obj == null)
			return null;
		if (obj instanceof org.jacorb.sasPolicy.SASPolicy)
			return (org.jacorb.sasPolicy.SASPolicy)obj;
		else
		throw new org.omg.CORBA.BAD_PARAM("unchecked_narrow failed, not a org.jacorb.sasPolicy.SASPolicy");
	}
}
