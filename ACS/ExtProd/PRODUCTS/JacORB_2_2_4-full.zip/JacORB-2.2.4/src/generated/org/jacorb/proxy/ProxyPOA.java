package org.jacorb.proxy;

/**
 *	Generated from IDL interface "Proxy"
 *	@author JacORB IDL compiler V 2.2.3, 10-Dec-2005
 */


public abstract class ProxyPOA
	extends org.omg.PortableServer.Servant
	implements org.omg.CORBA.portable.InvokeHandler, org.jacorb.proxy.ProxyOperations
{
	private String[] ids = {"IDL:org/jacorb/proxy/Proxy:1.0"};
	public org.jacorb.proxy.Proxy _this()
	{
		return org.jacorb.proxy.ProxyHelper.narrow(_this_object());
	}
	public org.jacorb.proxy.Proxy _this(org.omg.CORBA.ORB orb)
	{
		return org.jacorb.proxy.ProxyHelper.narrow(_this_object(orb));
	}
	public org.omg.CORBA.portable.OutputStream _invoke(String method, org.omg.CORBA.portable.InputStream _input, org.omg.CORBA.portable.ResponseHandler handler)
		throws org.omg.CORBA.SystemException
	{
		org.omg.CORBA.portable.OutputStream _out = null;
		// do something
		throw new org.omg.CORBA.BAD_OPERATION(method + " not found");
	}

	public String[] _all_interfaces(org.omg.PortableServer.POA poa, byte[] obj_id)
	{
		return ids;
	}
}
