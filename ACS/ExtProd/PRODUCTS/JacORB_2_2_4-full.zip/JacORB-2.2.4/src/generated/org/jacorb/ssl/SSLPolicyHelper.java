package org.jacorb.ssl;


/**
 *	Generated from IDL interface "SSLPolicy"
 *	@author JacORB IDL compiler V 2.2.3, 10-Dec-2005
 */

public final class SSLPolicyHelper
{
	public static void insert (final org.omg.CORBA.Any any, final org.jacorb.ssl.SSLPolicy s)
	{
			any.insert_Object(s);
	}
	public static org.jacorb.ssl.SSLPolicy extract(final org.omg.CORBA.Any any)
	{
		return narrow(any.extract_Object()) ;
	}
	public static org.omg.CORBA.TypeCode type()
	{
		return org.omg.CORBA.ORB.init().create_interface_tc("IDL:org/jacorb/ssl/SSLPolicy:1.0", "SSLPolicy");
	}
	public static String id()
	{
		return "IDL:org/jacorb/ssl/SSLPolicy:1.0";
	}
	public static SSLPolicy read(final org.omg.CORBA.portable.InputStream in)
	{
		throw new org.omg.CORBA.MARSHAL();
	}
	public static void write(final org.omg.CORBA.portable.OutputStream _out, final org.jacorb.ssl.SSLPolicy s)
	{
		throw new org.omg.CORBA.MARSHAL();
	}
	public static org.jacorb.ssl.SSLPolicy narrow(final java.lang.Object obj)
	{
		if (obj instanceof org.jacorb.ssl.SSLPolicy)
		{
			return (org.jacorb.ssl.SSLPolicy)obj;
		}
		else if (obj instanceof org.omg.CORBA.Object)
		{
			return narrow((org.omg.CORBA.Object)obj);
		}
		throw new org.omg.CORBA.BAD_PARAM("Failed to narrow in helper");
	}
	public static org.jacorb.ssl.SSLPolicy narrow(final org.omg.CORBA.Object obj)
	{
		if (obj == null)
			return null;
		if (obj instanceof org.jacorb.ssl.SSLPolicy)
			return (org.jacorb.ssl.SSLPolicy)obj;
		else
		throw new org.omg.CORBA.BAD_PARAM("Narrow failed, not a org.jacorb.ssl.SSLPolicy");
	}
	public static org.jacorb.ssl.SSLPolicy unchecked_narrow(final org.omg.CORBA.Object obj)
	{
		if (obj == null)
			return null;
		if (obj instanceof org.jacorb.ssl.SSLPolicy)
			return (org.jacorb.ssl.SSLPolicy)obj;
		else
		throw new org.omg.CORBA.BAD_PARAM("unchecked_narrow failed, not a org.jacorb.ssl.SSLPolicy");
	}
}
