/*
 * Generated file - Do not edit!
 */
package org.jacorb.notification.servant;

/**
 * MBean interface.
 */
public interface SequenceProxyPushConsumerImplMBean extends org.jacorb.notification.servant.AbstractProxyConsumerMBean {

}
