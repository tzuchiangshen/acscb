package org.jacorb.sasPolicy;

/**
 *	Generated from IDL definition of struct "SASPolicyValues"
 *	@author JacORB IDL compiler 
 */

public final class SASPolicyValues
	implements org.omg.CORBA.portable.IDLEntity
{
	public SASPolicyValues(){}
	public short targetRequires;
	public short targetSupports;
	public boolean stateful;
	public SASPolicyValues(short targetRequires, short targetSupports, boolean stateful)
	{
		this.targetRequires = targetRequires;
		this.targetSupports = targetSupports;
		this.stateful = stateful;
	}
}
