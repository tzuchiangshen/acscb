/*
 * Generated file - Do not edit!
 */
package org.jacorb.notification.servant;

/**
 * MBean interface.
 */
public interface AbstractProxyConsumerMBean extends org.jacorb.notification.servant.AbstractProxyMBean {

  boolean getStopTimeSupported() ;

  boolean getStartTimeSupported() ;

  int getMessageCount() ;

}
