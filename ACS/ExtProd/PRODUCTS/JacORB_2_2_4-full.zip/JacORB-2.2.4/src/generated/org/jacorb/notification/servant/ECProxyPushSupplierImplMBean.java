/*
 * Generated file - Do not edit!
 */
package org.jacorb.notification.servant;

/**
 * MBean interface.
 */
public interface ECProxyPushSupplierImplMBean extends org.jacorb.notification.servant.AbstractProxyPushSupplierMBean {

}
