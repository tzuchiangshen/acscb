package org.omg.BiDirPolicy;
/**
 * Automatically generated from IDL const definition 
 * @author JacORB IDL compiler 
 */

public interface NORMAL
{
	short value = (short)(0);
}
