package org.jacorb.util.tracing;


/**
 *	Generated from IDL definition of struct "TraceData"
 *	@author JacORB IDL compiler 
 */

public final class TraceDataHelper
{
	private static org.omg.CORBA.TypeCode _type = null;
	public static org.omg.CORBA.TypeCode type ()
	{
		if (_type == null)
		{
			_type = org.omg.CORBA.ORB.init().create_struct_tc(org.jacorb.util.tracing.TraceDataHelper.id(),"TraceData",new org.omg.CORBA.StructMember[]{new org.omg.CORBA.StructMember("subtrace", org.omg.CORBA.ORB.init().create_sequence_tc(0, org.omg.CORBA.ORB.init().create_recursive_tc("IDL:org/jacorb/util/tracing/TraceData:1.0")), null),new org.omg.CORBA.StructMember("tracer_id", org.jacorb.util.tracing.PointIdHelper.type(), null),new org.omg.CORBA.StructMember("operation", org.omg.CORBA.ORB.init().create_string_tc(0), null),new org.omg.CORBA.StructMember("client_time", org.jacorb.util.tracing.MSecHelper.type(), null),new org.omg.CORBA.StructMember("trace_system_time", org.jacorb.util.tracing.MSecHelper.type(), null)});
		}
		return _type;
	}

	public static void insert (final org.omg.CORBA.Any any, final org.jacorb.util.tracing.TraceData s)
	{
		any.type(type());
		write( any.create_output_stream(),s);
	}

	public static org.jacorb.util.tracing.TraceData extract (final org.omg.CORBA.Any any)
	{
		return read(any.create_input_stream());
	}

	public static String id()
	{
		return "IDL:org/jacorb/util/tracing/TraceData:1.0";
	}
	public static org.jacorb.util.tracing.TraceData read (final org.omg.CORBA.portable.InputStream in)
	{
		org.jacorb.util.tracing.TraceData result = new org.jacorb.util.tracing.TraceData();
		int _lresult_subtrace0 = in.read_long();
		result.subtrace = new org.jacorb.util.tracing.TraceData[_lresult_subtrace0];
		for (int i=0;i<result.subtrace.length;i++)
		{
			result.subtrace[i]=org.jacorb.util.tracing.TraceDataHelper.read(in);
		}

		result.tracer_id=in.read_long();
		result.operation=in.read_string();
		result.client_time=in.read_longlong();
		result.trace_system_time=in.read_longlong();
		return result;
	}
	public static void write (final org.omg.CORBA.portable.OutputStream out, final org.jacorb.util.tracing.TraceData s)
	{
		
		out.write_long(s.subtrace.length);
		for (int i=0; i<s.subtrace.length;i++)
		{
			org.jacorb.util.tracing.TraceDataHelper.write(out,s.subtrace[i]);
		}

		out.write_long(s.tracer_id);
		out.write_string(s.operation);
		out.write_longlong(s.client_time);
		out.write_longlong(s.trace_system_time);
	}
}
