package org.omg.BiDirPolicy;

/**
 *	Generated from IDL interface "BidirectionalPolicy"
 *	@author JacORB IDL compiler V 2.2.3, 10-Dec-2005
 */

public interface BidirectionalPolicy
	extends BidirectionalPolicyOperations, org.omg.CORBA.Object, org.omg.CORBA.portable.IDLEntity, org.omg.CORBA.Policy
{
}
