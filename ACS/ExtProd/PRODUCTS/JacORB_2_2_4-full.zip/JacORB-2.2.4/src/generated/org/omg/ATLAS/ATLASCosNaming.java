package org.omg.ATLAS;
/**
 * Automatically generated from IDL const definition 
 * @author JacORB IDL compiler 
 */

public interface ATLASCosNaming
{
	int value = 1;
}
