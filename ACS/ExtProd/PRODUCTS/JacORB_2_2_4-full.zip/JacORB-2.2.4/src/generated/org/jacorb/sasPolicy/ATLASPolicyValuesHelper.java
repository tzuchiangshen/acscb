package org.jacorb.sasPolicy;


/**
 *	Generated from IDL definition of struct "ATLASPolicyValues"
 *	@author JacORB IDL compiler 
 */

public final class ATLASPolicyValuesHelper
{
	private static org.omg.CORBA.TypeCode _type = null;
	public static org.omg.CORBA.TypeCode type ()
	{
		if (_type == null)
		{
			_type = org.omg.CORBA.ORB.init().create_struct_tc(org.jacorb.sasPolicy.ATLASPolicyValuesHelper.id(),"ATLASPolicyValues",new org.omg.CORBA.StructMember[]{new org.omg.CORBA.StructMember("atlasURL", org.omg.CORBA.ORB.init().create_string_tc(0), null),new org.omg.CORBA.StructMember("atlasCache", org.omg.CORBA.ORB.init().create_string_tc(0), null)});
		}
		return _type;
	}

	public static void insert (final org.omg.CORBA.Any any, final org.jacorb.sasPolicy.ATLASPolicyValues s)
	{
		any.type(type());
		write( any.create_output_stream(),s);
	}

	public static org.jacorb.sasPolicy.ATLASPolicyValues extract (final org.omg.CORBA.Any any)
	{
		return read(any.create_input_stream());
	}

	public static String id()
	{
		return "IDL:org/jacorb/sasPolicy/ATLASPolicyValues:1.0";
	}
	public static org.jacorb.sasPolicy.ATLASPolicyValues read (final org.omg.CORBA.portable.InputStream in)
	{
		org.jacorb.sasPolicy.ATLASPolicyValues result = new org.jacorb.sasPolicy.ATLASPolicyValues();
		result.atlasURL=in.read_string();
		result.atlasCache=in.read_string();
		return result;
	}
	public static void write (final org.omg.CORBA.portable.OutputStream out, final org.jacorb.sasPolicy.ATLASPolicyValues s)
	{
		out.write_string(s.atlasURL);
		out.write_string(s.atlasCache);
	}
}
