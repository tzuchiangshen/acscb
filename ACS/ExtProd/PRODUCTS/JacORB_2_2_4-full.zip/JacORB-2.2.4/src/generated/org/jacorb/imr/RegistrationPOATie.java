package org.jacorb.imr;

import org.omg.PortableServer.POA;

/**
 *	Generated from IDL interface "Registration"
 *	@author JacORB IDL compiler V 2.2.3, 10-Dec-2005
 */

public class RegistrationPOATie
	extends RegistrationPOA
{
	private RegistrationOperations _delegate;

	private POA _poa;
	public RegistrationPOATie(RegistrationOperations delegate)
	{
		_delegate = delegate;
	}
	public RegistrationPOATie(RegistrationOperations delegate, POA poa)
	{
		_delegate = delegate;
		_poa = poa;
	}
	public org.jacorb.imr.Registration _this()
	{
		return org.jacorb.imr.RegistrationHelper.narrow(_this_object());
	}
	public org.jacorb.imr.Registration _this(org.omg.CORBA.ORB orb)
	{
		return org.jacorb.imr.RegistrationHelper.narrow(_this_object(orb));
	}
	public RegistrationOperations _delegate()
	{
		return _delegate;
	}
	public void _delegate(RegistrationOperations delegate)
	{
		_delegate = delegate;
	}
	public POA _default_POA()
	{
		if (_poa != null)
		{
			return _poa;
		}
		else
		{
			return super._default_POA();
		}
	}
	public org.jacorb.imr.ImRInfo get_imr_info()
	{
		return _delegate.get_imr_info();
	}

	public void register_poa(java.lang.String name, java.lang.String server, java.lang.String host, int port) throws org.jacorb.imr.RegistrationPackage.IllegalPOAName,org.jacorb.imr.RegistrationPackage.DuplicatePOAName,org.jacorb.imr.UnknownServerName
	{
_delegate.register_poa(name,server,host,port);
	}

	public void set_server_down(java.lang.String name) throws org.jacorb.imr.UnknownServerName
	{
_delegate.set_server_down(name);
	}

	public void register_host(org.jacorb.imr.HostInfo info) throws org.jacorb.imr.RegistrationPackage.InvalidSSDRef,org.jacorb.imr.RegistrationPackage.IllegalHostName
	{
_delegate.register_host(info);
	}

}
