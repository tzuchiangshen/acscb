package org.omg.BiDirPolicy;
/**
 * Automatically generated from IDL const definition 
 * @author JacORB IDL compiler 
 */

public interface BOTH
{
	short value = (short)(1);
}
