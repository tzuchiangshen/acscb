package org.jacorb.imr.RegistrationPackage;

/**
 *	Generated from IDL definition of exception "InvalidSSDRef"
 *	@author JacORB IDL compiler 
 */

public final class InvalidSSDRef
	extends org.omg.CORBA.UserException
{
	public InvalidSSDRef()
	{
		super(org.jacorb.imr.RegistrationPackage.InvalidSSDRefHelper.id());
	}

	public InvalidSSDRef(String value)
	{
		super(value);
	}
}
