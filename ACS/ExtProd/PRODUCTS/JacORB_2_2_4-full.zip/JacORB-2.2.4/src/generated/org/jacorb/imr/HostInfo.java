package org.jacorb.imr;

/**
 *	Generated from IDL definition of struct "HostInfo"
 *	@author JacORB IDL compiler 
 */

public final class HostInfo
	implements org.omg.CORBA.portable.IDLEntity
{
	public HostInfo(){}
	public java.lang.String name;
	public org.jacorb.imr.ServerStartupDaemon ssd_ref;
	public java.lang.String ior_string;
	public HostInfo(java.lang.String name, org.jacorb.imr.ServerStartupDaemon ssd_ref, java.lang.String ior_string)
	{
		this.name = name;
		this.ssd_ref = ssd_ref;
		this.ior_string = ior_string;
	}
}
