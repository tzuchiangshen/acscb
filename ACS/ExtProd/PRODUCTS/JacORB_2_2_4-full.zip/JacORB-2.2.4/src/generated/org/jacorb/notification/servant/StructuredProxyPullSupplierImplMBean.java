/*
 * Generated file - Do not edit!
 */
package org.jacorb.notification.servant;

/**
 * MBean interface.
 */
public interface StructuredProxyPullSupplierImplMBean extends org.jacorb.notification.servant.AbstractProxyMBean {

}
