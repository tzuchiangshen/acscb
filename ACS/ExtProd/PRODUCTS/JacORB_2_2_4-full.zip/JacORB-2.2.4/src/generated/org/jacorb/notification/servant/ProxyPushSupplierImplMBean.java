/*
 * Generated file - Do not edit!
 */
package org.jacorb.notification.servant;

/**
 * MBean interface.
 */
public interface ProxyPushSupplierImplMBean extends org.jacorb.notification.servant.AbstractProxyPushSupplierMBean {

}
