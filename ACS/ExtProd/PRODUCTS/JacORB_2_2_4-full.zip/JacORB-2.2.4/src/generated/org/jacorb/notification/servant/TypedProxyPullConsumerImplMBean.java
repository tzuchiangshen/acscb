/*
 * Generated file - Do not edit!
 */
package org.jacorb.notification.servant;

/**
 * MBean interface.
 */
public interface TypedProxyPullConsumerImplMBean extends org.jacorb.notification.servant.AbstractProxyConsumerMBean {

  java.lang.String getSupportedInterface() ;

}
