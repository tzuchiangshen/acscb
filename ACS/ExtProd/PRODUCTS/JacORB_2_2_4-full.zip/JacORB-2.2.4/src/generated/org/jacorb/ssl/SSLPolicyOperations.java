package org.jacorb.ssl;

/**
 *	Generated from IDL interface "SSLPolicy"
 *	@author JacORB IDL compiler V 2.2.3, 10-Dec-2005
 */


public interface SSLPolicyOperations
	extends org.omg.CORBA.PolicyOperations
{
	/* constants */
	/* operations  */
	org.jacorb.ssl.SSLPolicyValue value();
}
