package org.jacorb.imr;

/**
 *	Generated from IDL interface "ImplementationRepository"
 *	@author JacORB IDL compiler V 2.2.3, 10-Dec-2005
 */

public interface ImplementationRepository
	extends ImplementationRepositoryOperations, org.omg.CORBA.Object, org.omg.CORBA.portable.IDLEntity, org.jacorb.imr.Registration, org.jacorb.imr.Admin
{
}
