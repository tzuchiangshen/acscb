package org.omg.ATLAS;
/**
 * Automatically generated from IDL const definition 
 * @author JacORB IDL compiler 
 */

public interface SCS_ATLAS
{
	int value = 3;
}
