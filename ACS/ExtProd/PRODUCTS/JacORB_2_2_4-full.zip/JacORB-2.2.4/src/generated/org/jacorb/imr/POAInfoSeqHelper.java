package org.jacorb.imr;

/**
 *	Generated from IDL definition of alias "POAInfoSeq"
 *	@author JacORB IDL compiler 
 */

public final class POAInfoSeqHelper
{
	private static org.omg.CORBA.TypeCode _type = null;

	public static void insert (org.omg.CORBA.Any any, org.jacorb.imr.POAInfo[] s)
	{
		any.type (type ());
		write (any.create_output_stream (), s);
	}

	public static org.jacorb.imr.POAInfo[] extract (final org.omg.CORBA.Any any)
	{
		return read (any.create_input_stream ());
	}

	public static org.omg.CORBA.TypeCode type ()
	{
		if (_type == null)
		{
			_type = org.omg.CORBA.ORB.init().create_alias_tc(org.jacorb.imr.POAInfoSeqHelper.id(), "POAInfoSeq",org.omg.CORBA.ORB.init().create_sequence_tc(0, org.jacorb.imr.POAInfoHelper.type()));
		}
		return _type;
	}

	public static String id()
	{
		return "IDL:org/jacorb/imr/POAInfoSeq:1.0";
	}
	public static org.jacorb.imr.POAInfo[] read (final org.omg.CORBA.portable.InputStream _in)
	{
		org.jacorb.imr.POAInfo[] _result;
		int _l_result126 = _in.read_long();
		_result = new org.jacorb.imr.POAInfo[_l_result126];
		for (int i=0;i<_result.length;i++)
		{
			_result[i]=org.jacorb.imr.POAInfoHelper.read(_in);
		}

		return _result;
	}

	public static void write (final org.omg.CORBA.portable.OutputStream _out, org.jacorb.imr.POAInfo[] _s)
	{
		
		_out.write_long(_s.length);
		for (int i=0; i<_s.length;i++)
		{
			org.jacorb.imr.POAInfoHelper.write(_out,_s[i]);
		}

	}
}
