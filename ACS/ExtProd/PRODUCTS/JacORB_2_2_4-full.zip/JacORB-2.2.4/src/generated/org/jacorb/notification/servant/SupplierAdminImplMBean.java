/*
 * Generated file - Do not edit!
 */
package org.jacorb.notification.servant;

/**
 * MBean interface.
 */
public interface SupplierAdminImplMBean extends org.jacorb.notification.servant.AbstractAdminMBean {

}
