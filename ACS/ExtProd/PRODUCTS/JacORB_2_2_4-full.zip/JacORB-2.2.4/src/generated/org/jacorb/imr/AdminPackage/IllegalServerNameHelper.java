package org.jacorb.imr.AdminPackage;


/**
 *	Generated from IDL definition of exception "IllegalServerName"
 *	@author JacORB IDL compiler 
 */

public final class IllegalServerNameHelper
{
	private static org.omg.CORBA.TypeCode _type = null;
	public static org.omg.CORBA.TypeCode type ()
	{
		if (_type == null)
		{
			_type = org.omg.CORBA.ORB.init().create_exception_tc(org.jacorb.imr.AdminPackage.IllegalServerNameHelper.id(),"IllegalServerName",new org.omg.CORBA.StructMember[]{new org.omg.CORBA.StructMember("name", org.jacorb.imr.LogicalServerNameHelper.type(), null)});
		}
		return _type;
	}

	public static void insert (final org.omg.CORBA.Any any, final org.jacorb.imr.AdminPackage.IllegalServerName s)
	{
		any.type(type());
		write( any.create_output_stream(),s);
	}

	public static org.jacorb.imr.AdminPackage.IllegalServerName extract (final org.omg.CORBA.Any any)
	{
		return read(any.create_input_stream());
	}

	public static String id()
	{
		return "IDL:org/jacorb/imr/Admin/IllegalServerName:1.0";
	}
	public static org.jacorb.imr.AdminPackage.IllegalServerName read (final org.omg.CORBA.portable.InputStream in)
	{
		org.jacorb.imr.AdminPackage.IllegalServerName result = new org.jacorb.imr.AdminPackage.IllegalServerName();
		if (!in.read_string().equals(id())) throw new org.omg.CORBA.MARSHAL("wrong id");
		result.name=in.read_string();
		return result;
	}
	public static void write (final org.omg.CORBA.portable.OutputStream out, final org.jacorb.imr.AdminPackage.IllegalServerName s)
	{
		out.write_string(id());
		out.write_string(s.name);
	}
}
