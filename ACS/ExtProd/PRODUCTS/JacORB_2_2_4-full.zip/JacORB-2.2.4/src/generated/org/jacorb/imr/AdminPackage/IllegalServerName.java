package org.jacorb.imr.AdminPackage;

/**
 *	Generated from IDL definition of exception "IllegalServerName"
 *	@author JacORB IDL compiler 
 */

public final class IllegalServerName
	extends org.omg.CORBA.UserException
{
	public IllegalServerName()
	{
		super(org.jacorb.imr.AdminPackage.IllegalServerNameHelper.id());
	}

	public java.lang.String name;
	public IllegalServerName(java.lang.String _reason,java.lang.String name)
	{
		super(org.jacorb.imr.AdminPackage.IllegalServerNameHelper.id()+ " " + _reason);
		this.name = name;
	}
	public IllegalServerName(java.lang.String name)
	{
		super(org.jacorb.imr.AdminPackage.IllegalServerNameHelper.id());
		this.name = name;
	}
}
