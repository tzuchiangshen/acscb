package org.jacorb.util.tracing;
/**
 * Automatically generated from IDL const definition 
 * @author JacORB IDL compiler 
 */

public interface TracingContextID
{
	int value = 2130771712;
}
