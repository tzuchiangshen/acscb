package org.jacorb.events;

/**
 *	Generated from IDL interface "JacORBEventChannel"
 *	@author JacORB IDL compiler V 2.2.3, 10-Dec-2005
 */

public interface JacORBEventChannel
	extends JacORBEventChannelOperations, org.omg.CORBA.Object, org.omg.CORBA.portable.IDLEntity, org.omg.CosEventChannelAdmin.EventChannel, org.omg.CosEventChannelAdmin.ConsumerAdmin, org.omg.CosEventChannelAdmin.SupplierAdmin
{
}
