package org.jacorb.imr;

/**
 *	Generated from IDL definition of struct "ServerInfo"
 *	@author JacORB IDL compiler 
 */

public final class ServerInfo
	implements org.omg.CORBA.portable.IDLEntity
{
	public ServerInfo(){}
	public java.lang.String name;
	public java.lang.String command;
	public org.jacorb.imr.POAInfo[] poas;
	public java.lang.String host;
	public boolean active;
	public boolean holding;
	public ServerInfo(java.lang.String name, java.lang.String command, org.jacorb.imr.POAInfo[] poas, java.lang.String host, boolean active, boolean holding)
	{
		this.name = name;
		this.command = command;
		this.poas = poas;
		this.host = host;
		this.active = active;
		this.holding = holding;
	}
}
