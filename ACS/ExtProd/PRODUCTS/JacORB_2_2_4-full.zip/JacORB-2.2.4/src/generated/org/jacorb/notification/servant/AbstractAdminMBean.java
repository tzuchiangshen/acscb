/*
 * Generated file - Do not edit!
 */
package org.jacorb.notification.servant;

/**
 * MBean interface.
 */
public interface AbstractAdminMBean {

  void destroy() ;

  java.lang.Integer getID() ;

  java.lang.String getInterFilterGroupOperator() ;

}
