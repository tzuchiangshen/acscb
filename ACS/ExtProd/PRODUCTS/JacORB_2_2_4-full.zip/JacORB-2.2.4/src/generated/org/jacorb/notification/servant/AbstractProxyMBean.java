/*
 * Generated file - Do not edit!
 */
package org.jacorb.notification.servant;

/**
 * MBean interface.
 */
public interface AbstractProxyMBean {

  void destroy() ;

  boolean getConnected() ;

  void resetErrorCounter() ;

  int getErrorCounter() ;

  java.lang.String getStatus() ;

  java.lang.String getClientIOR() ;

  java.lang.String getInterFilterGroupOperator() ;

}
