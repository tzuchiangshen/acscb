package org.omg.ATLAS;

/**
 *	Generated from IDL definition of exception "TokenOkay"
 *	@author JacORB IDL compiler 
 */

public final class TokenOkay
	extends org.omg.CORBA.UserException
{
	public TokenOkay()
	{
		super(org.omg.ATLAS.TokenOkayHelper.id());
	}

	public TokenOkay(String value)
	{
		super(value);
	}
}
