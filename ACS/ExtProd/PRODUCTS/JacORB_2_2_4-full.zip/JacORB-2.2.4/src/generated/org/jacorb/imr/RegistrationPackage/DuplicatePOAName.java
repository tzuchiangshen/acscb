package org.jacorb.imr.RegistrationPackage;

/**
 *	Generated from IDL definition of exception "DuplicatePOAName"
 *	@author JacORB IDL compiler 
 */

public final class DuplicatePOAName
	extends org.omg.CORBA.UserException
{
	public DuplicatePOAName()
	{
		super(org.jacorb.imr.RegistrationPackage.DuplicatePOANameHelper.id());
	}

	public java.lang.String name;
	public DuplicatePOAName(java.lang.String _reason,java.lang.String name)
	{
		super(org.jacorb.imr.RegistrationPackage.DuplicatePOANameHelper.id()+ " " + _reason);
		this.name = name;
	}
	public DuplicatePOAName(java.lang.String name)
	{
		super(org.jacorb.imr.RegistrationPackage.DuplicatePOANameHelper.id());
		this.name = name;
	}
}
