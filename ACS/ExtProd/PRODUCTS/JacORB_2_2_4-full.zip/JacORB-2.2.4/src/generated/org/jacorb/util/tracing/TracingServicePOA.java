package org.jacorb.util.tracing;

/**
 *	Generated from IDL interface "TracingService"
 *	@author JacORB IDL compiler V 2.2.3, 10-Dec-2005
 */


public abstract class TracingServicePOA
	extends org.omg.PortableServer.Servant
	implements org.omg.CORBA.portable.InvokeHandler, org.jacorb.util.tracing.TracingServiceOperations
{
	static private final java.util.Hashtable m_opsHash = new java.util.Hashtable();
	static
	{
		m_opsHash.put ( "get_id", new java.lang.Integer(0));
		m_opsHash.put ( "logTraceAtPoint", new java.lang.Integer(1));
		m_opsHash.put ( "getTrace", new java.lang.Integer(2));
		m_opsHash.put ( "registerSubTrace", new java.lang.Integer(3));
	}
	private String[] ids = {"IDL:org/jacorb/util/tracing/TracingService:1.0"};
	public org.jacorb.util.tracing.TracingService _this()
	{
		return org.jacorb.util.tracing.TracingServiceHelper.narrow(_this_object());
	}
	public org.jacorb.util.tracing.TracingService _this(org.omg.CORBA.ORB orb)
	{
		return org.jacorb.util.tracing.TracingServiceHelper.narrow(_this_object(orb));
	}
	public org.omg.CORBA.portable.OutputStream _invoke(String method, org.omg.CORBA.portable.InputStream _input, org.omg.CORBA.portable.ResponseHandler handler)
		throws org.omg.CORBA.SystemException
	{
		org.omg.CORBA.portable.OutputStream _out = null;
		// do something
		// quick lookup of operation
		java.lang.Integer opsIndex = (java.lang.Integer)m_opsHash.get ( method );
		if ( null == opsIndex )
			throw new org.omg.CORBA.BAD_OPERATION(method + " not found");
		switch ( opsIndex.intValue() )
		{
			case 0: // get_id
			{
				_out = handler.createReply();
				_out.write_long(get_id());
				break;
			}
			case 1: // logTraceAtPoint
			{
			try
			{
				org.jacorb.util.tracing.Request _arg0=org.jacorb.util.tracing.RequestHelper.read(_input);
				java.lang.String _arg1=_input.read_string();
				long _arg2=_input.read_longlong();
				long _arg3=_input.read_longlong();
				_out = handler.createReply();
				logTraceAtPoint(_arg0,_arg1,_arg2,_arg3);
			}
			catch(org.jacorb.util.tracing.TracingServicePackage.NoSuchRequestId _ex0)
			{
				_out = handler.createExceptionReply();
				org.jacorb.util.tracing.TracingServicePackage.NoSuchRequestIdHelper.write(_out, _ex0);
			}
				break;
			}
			case 2: // getTrace
			{
			try
			{
				org.jacorb.util.tracing.Request _arg0=org.jacorb.util.tracing.RequestHelper.read(_input);
				_out = handler.createReply();
				org.jacorb.util.tracing.TraceDataHelper.write(_out,getTrace(_arg0));
			}
			catch(org.jacorb.util.tracing.TracingServicePackage.NoSuchRequestId _ex0)
			{
				_out = handler.createExceptionReply();
				org.jacorb.util.tracing.TracingServicePackage.NoSuchRequestIdHelper.write(_out, _ex0);
			}
				break;
			}
			case 3: // registerSubTrace
			{
			try
			{
				org.jacorb.util.tracing.Request _arg0=org.jacorb.util.tracing.RequestHelper.read(_input);
				org.jacorb.util.tracing.Request _arg1=org.jacorb.util.tracing.RequestHelper.read(_input);
				_out = handler.createReply();
				registerSubTrace(_arg0,_arg1);
			}
			catch(org.jacorb.util.tracing.TracingServicePackage.NoSuchRequestId _ex0)
			{
				_out = handler.createExceptionReply();
				org.jacorb.util.tracing.TracingServicePackage.NoSuchRequestIdHelper.write(_out, _ex0);
			}
				break;
			}
		}
		return _out;
	}

	public String[] _all_interfaces(org.omg.PortableServer.POA poa, byte[] obj_id)
	{
		return ids;
	}
}
