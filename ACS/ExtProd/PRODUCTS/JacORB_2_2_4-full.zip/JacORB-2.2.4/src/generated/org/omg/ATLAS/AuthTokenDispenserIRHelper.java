package org.omg.ATLAS;


/**
 * This class contains generated Interface Repository information.
 * @author JacORB IDL compiler.
 */

public class AuthTokenDispenserIRHelper
{
	public static java.util.Hashtable irInfo = new java.util.Hashtable();
	static
	{
		irInfo.put("get_my_authorization_token", "()");
		irInfo.put("translate_authorization_token", "(in:the_subject ,in:the_token org.omg.CSI.AuthorizationToken)");
	}
}
