package org.omg.BiDirPolicy;


/**
 * This class contains generated Interface Repository information.
 * @author JacORB IDL compiler.
 */

public class BidirectionalPolicyIRHelper
{
	public static java.util.Hashtable irInfo = new java.util.Hashtable();
	static
	{
		irInfo.put("value", "attribute;org.omg.BiDirPolicy.BidirectionalPolicyValue");
	}
}
