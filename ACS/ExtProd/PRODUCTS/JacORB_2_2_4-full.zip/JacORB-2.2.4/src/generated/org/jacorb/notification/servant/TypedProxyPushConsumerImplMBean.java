/*
 * Generated file - Do not edit!
 */
package org.jacorb.notification.servant;

/**
 * MBean interface.
 */
public interface TypedProxyPushConsumerImplMBean extends org.jacorb.notification.servant.AbstractProxyConsumerMBean {

  java.lang.String getSupportedInterface() ;

}
