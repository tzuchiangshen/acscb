package org.jacorb.imr;

/**
 *	Generated from IDL definition of alias "POAInfoSeq"
 *	@author JacORB IDL compiler 
 */

public final class POAInfoSeqHolder
	implements org.omg.CORBA.portable.Streamable
{
	public org.jacorb.imr.POAInfo[] value;

	public POAInfoSeqHolder ()
	{
	}
	public POAInfoSeqHolder (final org.jacorb.imr.POAInfo[] initial)
	{
		value = initial;
	}
	public org.omg.CORBA.TypeCode _type ()
	{
		return POAInfoSeqHelper.type ();
	}
	public void _read (final org.omg.CORBA.portable.InputStream in)
	{
		value = POAInfoSeqHelper.read (in);
	}
	public void _write (final org.omg.CORBA.portable.OutputStream out)
	{
		POAInfoSeqHelper.write (out,value);
	}
}
