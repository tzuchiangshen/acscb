/*
 * Generated file - Do not edit!
 */
package org.jacorb.notification.filter;

/**
 * MBean interface.
 */
public interface AbstractFilterMBean {

  void destroy() ;

  java.util.Date getLastUsage() ;

  java.util.Date getCreationDate() ;

  long getMatchCount() ;

  long getMatchStructuredCount() ;

  long getMatchTypedCount() ;

  java.lang.String listContraints() ;

}
