/*
 * Generated file - Do not edit!
 */
package org.jacorb.notification.servant;

/**
 * MBean interface.
 */
public interface SequenceProxyPushSupplierImplMBean extends org.jacorb.notification.servant.AbstractProxyPushSupplierMBean {

}
