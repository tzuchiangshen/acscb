/*
 * Generated file - Do not edit!
 */
package org.jacorb.notification.servant;

/**
 * MBean interface.
 */
public interface TypedProxyPushSupplierImplMBean extends org.jacorb.notification.servant.AbstractProxyPushSupplierMBean {

  java.lang.String getSupportedInterface() ;

}
