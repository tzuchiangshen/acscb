package org.jacorb.proxy;


/**
 *	Generated from IDL interface "Proxy"
 *	@author JacORB IDL compiler V 2.2.3, 10-Dec-2005
 */

public class _ProxyStub
	extends org.omg.CORBA.portable.ObjectImpl
	implements org.jacorb.proxy.Proxy
{
	private String[] ids = {"IDL:org/jacorb/proxy/Proxy:1.0"};
	public String[] _ids()
	{
		return ids;
	}

	public final static java.lang.Class _opsClass = org.jacorb.proxy.ProxyOperations.class;
}
