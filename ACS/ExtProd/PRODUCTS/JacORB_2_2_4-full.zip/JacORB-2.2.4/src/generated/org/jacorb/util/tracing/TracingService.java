package org.jacorb.util.tracing;

/**
 *	Generated from IDL interface "TracingService"
 *	@author JacORB IDL compiler V 2.2.3, 10-Dec-2005
 */

public interface TracingService
	extends TracingServiceOperations, org.omg.CORBA.Object, org.omg.CORBA.portable.IDLEntity
{
}
