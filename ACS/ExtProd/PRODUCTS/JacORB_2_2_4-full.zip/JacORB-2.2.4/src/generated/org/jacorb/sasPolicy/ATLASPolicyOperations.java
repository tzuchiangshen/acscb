package org.jacorb.sasPolicy;

/**
 *	Generated from IDL interface "ATLASPolicy"
 *	@author JacORB IDL compiler V 2.2.3, 10-Dec-2005
 */


public interface ATLASPolicyOperations
	extends org.omg.CORBA.PolicyOperations
{
	/* constants */
	/* operations  */
	org.jacorb.sasPolicy.ATLASPolicyValues value();
}
