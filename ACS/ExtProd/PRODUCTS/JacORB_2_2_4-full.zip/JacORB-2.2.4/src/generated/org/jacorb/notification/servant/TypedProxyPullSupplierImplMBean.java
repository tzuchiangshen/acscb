/*
 * Generated file - Do not edit!
 */
package org.jacorb.notification.servant;

/**
 * MBean interface.
 */
public interface TypedProxyPullSupplierImplMBean extends org.jacorb.notification.servant.AbstractProxySupplierMBean {

  int getPendingMessagesCount() ;

  java.lang.String getSupportedInterface() ;

}
