package org.jacorb.imr;

/**
 *	Generated from IDL definition of alias "ServerInfoSeq"
 *	@author JacORB IDL compiler 
 */

public final class ServerInfoSeqHelper
{
	private static org.omg.CORBA.TypeCode _type = null;

	public static void insert (org.omg.CORBA.Any any, org.jacorb.imr.ServerInfo[] s)
	{
		any.type (type ());
		write (any.create_output_stream (), s);
	}

	public static org.jacorb.imr.ServerInfo[] extract (final org.omg.CORBA.Any any)
	{
		return read (any.create_input_stream ());
	}

	public static org.omg.CORBA.TypeCode type ()
	{
		if (_type == null)
		{
			_type = org.omg.CORBA.ORB.init().create_alias_tc(org.jacorb.imr.ServerInfoSeqHelper.id(), "ServerInfoSeq",org.omg.CORBA.ORB.init().create_sequence_tc(0, org.jacorb.imr.ServerInfoHelper.type()));
		}
		return _type;
	}

	public static String id()
	{
		return "IDL:org/jacorb/imr/ServerInfoSeq:1.0";
	}
	public static org.jacorb.imr.ServerInfo[] read (final org.omg.CORBA.portable.InputStream _in)
	{
		org.jacorb.imr.ServerInfo[] _result;
		int _l_result127 = _in.read_long();
		_result = new org.jacorb.imr.ServerInfo[_l_result127];
		for (int i=0;i<_result.length;i++)
		{
			_result[i]=org.jacorb.imr.ServerInfoHelper.read(_in);
		}

		return _result;
	}

	public static void write (final org.omg.CORBA.portable.OutputStream _out, org.jacorb.imr.ServerInfo[] _s)
	{
		
		_out.write_long(_s.length);
		for (int i=0; i<_s.length;i++)
		{
			org.jacorb.imr.ServerInfoHelper.write(_out,_s[i]);
		}

	}
}
