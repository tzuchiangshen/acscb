CLASSPATH=../../../classes
export CLASSPATH

echo "start WhiteboardFactory"

../../../bin/jaco demo.notification.whiteboard.WhiteBoardFactory $*
