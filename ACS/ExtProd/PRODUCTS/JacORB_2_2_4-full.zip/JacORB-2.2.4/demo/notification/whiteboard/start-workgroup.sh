CLASSPATH=../../../classes
export CLASSPATH

../../../bin/jaco demo.notification.whiteboard.Workgroup
