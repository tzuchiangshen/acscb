#ifndef CCPP_DDS_DCPS_BUILTINTOPICS_H
#define CCPP_DDS_DCPS_BUILTINTOPICS_H



#ifdef CCPP_USE_CUSTOM_SUFFIX_DDS_DCPS_BUILTINTOPICS
#include "dds_dcps_builtintopics.h"
#include "dds_dcps_builtintopicsDcps.h"
#else
#include "dds_dcps_builtintopicsC.h"
#include "dds_dcps_builtintopicsDcpsC.h"
#endif

#include <orb_abstraction.h>
#include "dds_dcps_builtintopicsDcps_impl.h"



#endif /* CCPP_DDS_DCPS_BUILTINTOPICS_H */
