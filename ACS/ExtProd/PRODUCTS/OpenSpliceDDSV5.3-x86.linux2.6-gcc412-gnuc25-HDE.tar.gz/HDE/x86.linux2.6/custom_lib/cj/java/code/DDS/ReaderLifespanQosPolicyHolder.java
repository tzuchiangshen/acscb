package DDS;

public final class ReaderLifespanQosPolicyHolder
{

    public DDS.ReaderLifespanQosPolicy value = null;

    public ReaderLifespanQosPolicyHolder () { }

    public ReaderLifespanQosPolicyHolder (DDS.ReaderLifespanQosPolicy initialValue)
    {
        value = initialValue;
    }

}
