package DDS;

public final class ViewKeyQosPolicyHolder
{

    public DDS.ViewKeyQosPolicy value = null;

    public ViewKeyQosPolicyHolder () { }

    public ViewKeyQosPolicyHolder (DDS.ViewKeyQosPolicy initialValue)
    {
        value = initialValue;
    }

}
