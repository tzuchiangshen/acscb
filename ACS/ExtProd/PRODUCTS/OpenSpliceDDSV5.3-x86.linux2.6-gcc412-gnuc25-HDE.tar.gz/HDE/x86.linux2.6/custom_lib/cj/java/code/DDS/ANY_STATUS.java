/*
 *                         OpenSplice DDS
 *
 *   This software and documentation are Copyright 2006 to 2009 PrismTech 
 *   Limited and its licensees. All rights reserved. See file:
 *
 *                     $OSPL_HOME/LICENSE 
 *
 *   for full copyright notice and license terms. 
 *
 */

package DDS;

/* Note: ANY_STATUS is deprecated, please use spec version specific constants. 
   e.g. STATUS_MASK_ANY_V1_2 */
public interface ANY_STATUS
{
  public static final int value = (int)(0x7FE7L);
}
