package DDS;

public final class SubscriptionKeyQosPolicyHolder
{

    public DDS.SubscriptionKeyQosPolicy value = null;

    public SubscriptionKeyQosPolicyHolder () { }

    public SubscriptionKeyQosPolicyHolder (DDS.SubscriptionKeyQosPolicy initialValue)
    {
        value = initialValue;
    }

}
