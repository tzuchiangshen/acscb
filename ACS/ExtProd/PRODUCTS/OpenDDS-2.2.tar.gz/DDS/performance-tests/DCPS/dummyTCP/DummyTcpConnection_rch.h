// -*- C++ -*-
//
// $Id: DummyTcpConnection_rch.h 899 2007-07-05 16:36:52Z mitza $
#ifndef OPENDDS_DCPS_DUMMYTCPCONNECTION_RCH_H
#define OPENDDS_DCPS_DUMMYTCPCONNECTION_RCH_H

#include "dds/DCPS/RcHandle_T.h"


namespace OpenDDS
{

  namespace DCPS
  {

    class DummyTcpConnection;

    typedef RcHandle<DummyTcpConnection> DummyTcpConnection_rch;

  }  /* namespace DCPS */

}  /* namespace OpenDDS */

#endif /* OPENDDS_DCPS_DUMMYTCPCONNECTION_RCH_H */
