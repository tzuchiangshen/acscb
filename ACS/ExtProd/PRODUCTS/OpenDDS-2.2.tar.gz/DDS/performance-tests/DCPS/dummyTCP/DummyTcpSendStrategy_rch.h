// -*- C++ -*-
//
// $Id: DummyTcpSendStrategy_rch.h 899 2007-07-05 16:36:52Z mitza $
#ifndef OPENDDS_DCPS_DUMMYTCPSENDSTRATEGY_RCH_H
#define OPENDDS_DCPS_DUMMYTCPSENDSTRATEGY_RCH_H

#include "dds/DCPS/RcHandle_T.h"


namespace OpenDDS
{

  namespace DCPS
  {

    class DummyTcpSendStrategy;

    typedef RcHandle<DummyTcpSendStrategy> DummyTcpSendStrategy_rch;

  }  /* namespace DCPS */

}  /* namespace OpenDDS */

#endif /* OPENDDS_DCPS_DUMMYTCPSENDSTRATEGY_RCH_H */
