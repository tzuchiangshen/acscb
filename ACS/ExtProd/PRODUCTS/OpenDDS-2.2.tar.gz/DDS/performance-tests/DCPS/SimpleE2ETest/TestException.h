#ifndef TESTEXCEPTION_H
#define TESTEXCEPTION_H

class TestException
{
  public:

    TestException()  {}
    ~TestException() {}
};

#endif
