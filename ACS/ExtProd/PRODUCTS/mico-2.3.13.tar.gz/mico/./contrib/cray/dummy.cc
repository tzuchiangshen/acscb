//
// This is just an empty main file needed for prelinking on Cray
// Unicos/CC platform
//
int
main(int argc, char** argv)
{
    return 0;
}
