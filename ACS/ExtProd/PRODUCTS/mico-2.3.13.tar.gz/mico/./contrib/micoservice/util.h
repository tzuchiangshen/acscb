#ifndef _UTIL_H_
	#define _UTIL_H_
	#include <string>

 const std::string error_string(int err);
 const std::string error_string();

#endif
