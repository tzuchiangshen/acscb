#!/bin/sh
rm -f ref
cp Johnson_IIOP_POA.ior ref
./client
