export JAVA_HOME=/usr/local/jdk1.4
export PATH=.:$JAVA_HOME/bin:/usr/local/bin:/usr/bin:/bin:/usr/bin/X11
export JBOSS_HOME=/usr/local/jboss-3.2.0
export CLASSPATH=.:$JBOSS_HOME/client/jboss-j2ee.jar
export MICO_HOME=/usr/local/mico
source $MICO_HOME/lib/mico-setup.sh
