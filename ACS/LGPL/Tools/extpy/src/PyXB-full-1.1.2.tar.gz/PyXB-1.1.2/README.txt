PyXB -- Python W3C XML Schema Bindings
Version 1.1.2

Distribution components:
  PyXB-base-1.1.2.tar.gz -- Complete release, nothing pre-built
  PyXB-doc-1.1.2.tar.gz -- Overlay with pre-built documentation
  PyXB-common-1.1.2.tar.gz -- Overlay with XHTML bindings
  PyXB-opengis-1.1.2.tar.gz -- Overlay with OpenGIS bindings
  PyXB-wsspat-1.1.2.tar.gz -- Overlay with WS-* bindings
  PyXB-full-1.1.2.tar.gz -- Complete release with all overlays

Installation:  python setup.py install

Documentation: doc/html

Help Forum: http://sourceforge.net/forum/forum.php?forum_id=956708

Mailing list: https://lists.sourceforge.net/lists/listinfo/pyxb-users
Archive: http://www.mail-archive.com/pyxb-users@lists.sourceforge.net

Bug reports: https://sourceforge.net/apps/trac/pyxb/
