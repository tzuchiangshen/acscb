pyxbgen \
  -u po2.xsd -m po2
