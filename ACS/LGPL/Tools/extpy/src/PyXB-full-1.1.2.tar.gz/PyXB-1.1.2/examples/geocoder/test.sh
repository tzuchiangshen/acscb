sh genbindings.sh \
 && python client.py
 
