A utility to look up the latitude and longitude of a US address.  See
http://geocoder.us.
