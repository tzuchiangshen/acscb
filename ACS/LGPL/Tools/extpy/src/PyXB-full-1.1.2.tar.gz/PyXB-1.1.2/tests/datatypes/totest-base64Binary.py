import unittest
import pyxb.binding.datatypes as xsd

class Test_base64Binary (unittest.TestCase):
    def testRange (self):
        self.assertFalse("Datatype base64Binary test not implemented")

if __name__ == '__main__':
    unittest.main()
